# Smart School Attendance System

A QR + face-verification attendance system: students scan a QR code and look at
the camera at a gate kiosk; the backend verifies both server-side, marks
IN/OUT, and notifies parents on WhatsApp. Admins manage students, QR codes,
and biometric consent; teachers correct records and export reports; parents
and students see attendance history. Every sensitive action is logged with a
reason.

## What's here

```
backend/    FastAPI + SQLAlchemy API, fully tested (pytest)
frontend/   React (Vite) app: scan kiosk (PWA) + role-based dashboard
```

## Quick start

### 1. Backend

```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then edit the secrets below
python -m app.seed          # creates demo accounts + 2 students
uvicorn app.main:app --reload --port 8000
```

**Before running for real**, generate real secrets for `.env` (the seed/demo
values above are placeholders):

```bash
python -c "import secrets; print(secrets.token_hex(32))"   # JWT_SECRET_KEY
python -c "import secrets; print(secrets.token_hex(32))"   # QR_SIGNING_SECRET
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"  # FIELD_ENCRYPTION_KEY
```

### 2. Frontend

```bash
cd frontend
npm install
echo "VITE_API_BASE=http://localhost:8000" > .env
npm run dev      # http://localhost:5173
```

### 3. Log in

Demo accounts (password `DemoPass123!` for all):

| Role    | Email                    |
|---------|---------------------------|
| Admin   | admin@school.demo         |
| Teacher | teacher@school.demo       |
| Parent  | parent1@school.demo       |
| Student | student1@school.demo      |

- `/login` → role-based dashboard at `/dashboard`
- `/scan` (admin/teacher only) → the gate scanning kiosk

To test a real scan: as admin, open **Students → Manage → Generate QR**,
screenshot/display the QR image, then open `/scan` on another device (or
another browser tab/window) and hold the QR up to the camera. Face
verification is **mocked** (see below) — it deterministically matches only
the exact same photo bytes the student's registered photo used, so for a
live demo re-upload the same photo file you use as the "live capture" test
image via **Students → Manage → Upload photo**, then present that same image
to the kiosk camera.

## Architecture decisions & what's mocked

| Area | Status | Notes |
|---|---|---|
| Auth (JWT + refresh cookie), RBAC, rate limiting, lockout | **Real** | httpOnly refresh cookie, bcrypt, per-role guards enforced server-side on every route |
| QR signing/revocation | **Real** | Signed JWT-style token; revocation checked against `qr_token_id` on the student row, not just signature validity |
| Field-level encryption (parent phone, face embedding) | **Real** | Fernet symmetric encryption; key from env only |
| Face verification | **Mocked, pluggable** | `FACE_PROVIDER=mock` derives a deterministic embedding from image bytes so the full match/no-match/threshold flow is demonstrable without a GPU. Swap in real InsightFace/FaceNet inference in `app/services/face_service.py` — the rest of the app only depends on the function contract (`verify_face`), not the implementation. |
| Liveness detection | **Mocked heuristic** | Rejects flat/blank images via pixel-intensity entropy. Replace with a real liveness SDK for production. |
| WhatsApp notifications | **Mocked, pluggable** | `WHATSAPP_PROVIDER=mock` logs the message and simulates occasional transient failures so the retry-with-backoff path is real and testable. Swap in Twilio/Meta Cloud API credentials and implement `_send_via_provider` in `app/services/notification_service.py` to go live. |
| Fraud/anomaly detection | **Real, simplified** | Duplicate-scan cooldown, device/location-change flagging — all real logic, tuned with conservative constants you'll want to calibrate against real usage. |
| Admin edit log / QR audit log / manual corrections log | **Real** | Every write from these flows requires a reason and is persisted, queryable in the dashboard's Audit log page. |

## Running tests

```bash
cd backend
python -m pytest tests/ -v
```

18 tests cover auth, RBAC boundaries, the full scan flow (success, duplicate,
face mismatch, tampered/revoked QR, malformed image), and validation rules.

## Security notes

- CORS is locked to `ALLOWED_ORIGINS` in `.env` — never `*` in production.
- HTTPS is enforced (behind a TLS-terminating proxy) when `ENVIRONMENT=production`.
- Errors never leak stack traces; unhandled exceptions return a correlation
  ID, with full detail only in server logs.
- Biometric data can be purged per-student via
  `DELETE /students/{id}/biometric-data` for data-deletion requests.
- Rate limits: login `10/minute`, scan `3/minute` per IP (tune in `.env`).

## Known simplifications (documented, not hidden)

- Teacher class-scoping (a teacher assigned to specific classes only) isn't
  implemented — all teachers currently see all students. A `class_assignments`
  table would be the natural extension.
- The mock face embedding is content-hash-based, not a real facial-feature
  extractor, so it cannot generalize across different photos of the same
  real person the way a production model would — it's built to prove out the
  full verification pipeline (upload → validate → embed → compare →
  threshold → decision), not to replace a real model.
