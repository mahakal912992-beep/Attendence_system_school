import { createContext, useContext, useEffect, useState, useCallback } from "react";
import api, { setAccessToken, setUnauthorizedHandler, apiErrorMessage } from "../api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const clearSession = useCallback(() => {
    setAccessToken(null);
    setUser(null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(clearSession);
  }, [clearSession]);

  useEffect(() => {
    // On load, try to silently refresh using the httpOnly cookie (if any)
    (async () => {
      try {
        const { data } = await api.post("/auth/refresh");
        setAccessToken(data.access_token);
        const me = await api.get("/auth/me");
        setUser(me.data);
      } catch {
        clearSession();
      } finally {
        setLoading(false);
      }
    })();
  }, [clearSession]);

  async function login(email, password) {
    const { data } = await api.post("/auth/login", { email, password });
    setAccessToken(data.access_token);
    const me = await api.get("/auth/me");
    setUser(me.data);
    return me.data;
  }

  async function logout() {
    try {
      await api.post("/auth/logout");
    } catch {
      /* best-effort */
    }
    clearSession();
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

export { apiErrorMessage };
