import { useAuth } from "../../context/AuthContext";
import SelfAttendanceView from "../../components/SelfAttendanceView";

export default function ChildAttendance() {
  const { user } = useAuth();
  return <SelfAttendanceView studentId={user?.parent_of_student_id} title="My child's attendance" />;
}
