import { useEffect, useRef, useState, useCallback } from "react";
import jsQR from "jsqr";
import api, { apiErrorMessage } from "../api";

const LOCATIONS = ["Main Gate", "Back Gate", "Bus Bay"];

function getDeviceId() {
  let id = localStorage.getItem("kiosk_device_id");
  if (!id) {
    id = "kiosk-" + Math.random().toString(36).slice(2, 10);
    localStorage.setItem("kiosk_device_id", id);
  }
  return id;
}

// STAGES: idle | scanning | verifying | success | error
export default function ScanKiosk() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(null);
  const busyRef = useRef(false);

  const [stage, setStage] = useState("idle");
  const [result, setResult] = useState(null); // { status, student_name, time, message }
  const [errorMsg, setErrorMsg] = useState("");
  const [location, setLocation] = useState(LOCATIONS[0]);
  const [cameraError, setCameraError] = useState("");

  const deviceId = getDeviceId();

  const resetToScanning = useCallback(() => {
    busyRef.current = false;
    setResult(null);
    setErrorMsg("");
    setStage("scanning");
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setStage("scanning");
        tick();
      } catch (err) {
        setCameraError("Camera access is required to scan. Please allow camera permissions and reload.");
      }
    }
    startCamera();
    return () => {
      cancelled = true;
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tick() {
    rafRef.current = requestAnimationFrame(tick);
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA || busyRef.current) return;

    const ctx = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height);

    if (code && code.data) {
      handleQrDetected(code.data);
    }
  }

  async function handleQrDetected(qrPayload) {
    if (busyRef.current) return;
    busyRef.current = true;
    setStage("verifying");

    // Capture the current frame as the "face" image (same camera moment).
    const canvas = canvasRef.current;
    const faceBase64 = canvas.toDataURL("image/png").split(",")[1];

    try {
      const { data } = await api.post("/scan/verify", {
        qr_payload: qrPayload,
        device_id: deviceId,
        location,
        face_image_base64: faceBase64,
      });
      setResult(data);
      setStage("success");
    } catch (err) {
      setErrorMsg(apiErrorMessage(err, "Verification failed."));
      setStage("error");
    }

    setTimeout(resetToScanning, 3200);
  }

  const statusColor = stage === "success" ? "var(--green)" : stage === "error" ? "var(--red)" : "var(--amber)";
  const statusLabel =
    stage === "idle" ? "Starting camera…" :
    stage === "scanning" ? "Show your QR code" :
    stage === "verifying" ? "Verifying…" :
    stage === "success" ? (result?.status === "IN" ? "Welcome in" : "Have a good one") :
    "Verification failed";

  return (
    <div style={{ minHeight: "100vh", background: "var(--ink)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ position: "absolute", top: 20, left: 24, color: "var(--ink-text)" }}>
        <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16 }}>⛩ Campus Gate</div>
      </div>

      <div style={{ position: "absolute", top: 20, right: 24 }}>
        <select
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          style={{ background: "var(--ink-raised)", color: "var(--ink-text)", border: "1px solid var(--ink-line)", borderRadius: 8, padding: "8px 12px", fontSize: 13 }}
        >
          {LOCATIONS.map((l) => (
            <option key={l} value={l}>{l}</option>
          ))}
        </select>
      </div>

      {cameraError ? (
        <div className="card" style={{ maxWidth: 420, textAlign: "center" }}>{cameraError}</div>
      ) : (
        <>
          <div
            style={{
              position: "relative",
              width: 360,
              height: 360,
              borderRadius: 20,
              overflow: "hidden",
              border: `3px solid ${statusColor}`,
              transition: "border-color 0.25s ease",
              background: "black",
            }}
          >
            <video ref={videoRef} muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            <canvas ref={canvasRef} style={{ display: "none" }} />

            {/* corner brackets - signature gate motif */}
            {["tl", "tr", "bl", "br"].map((pos) => (
              <div
                key={pos}
                style={{
                  position: "absolute",
                  width: 28,
                  height: 28,
                  borderColor: statusColor,
                  borderStyle: "solid",
                  transition: "border-color 0.25s ease",
                  top: pos.startsWith("t") ? 14 : "auto",
                  bottom: pos.startsWith("b") ? 14 : "auto",
                  left: pos.endsWith("l") ? 14 : "auto",
                  right: pos.endsWith("r") ? 14 : "auto",
                  borderWidth: `${pos.startsWith("t") ? 3 : 0}px ${pos.endsWith("r") ? 3 : 0}px ${pos.startsWith("b") ? 3 : 0}px ${pos.endsWith("l") ? 3 : 0}px`,
                  borderRadius: 4,
                }}
              />
            ))}

            {stage === "verifying" && (
              <div style={{ position: "absolute", inset: 0, background: "rgba(18,24,43,0.55)", display: "grid", placeItems: "center" }}>
                <div className="mono" style={{ color: "var(--ink-text)", fontSize: 13 }}>verifying…</div>
              </div>
            )}
          </div>

          <div style={{ marginTop: 24, textAlign: "center" }}>
            <div style={{ color: statusColor, fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 600, transition: "color 0.25s ease" }}>
              {statusLabel}
            </div>

            {stage === "success" && result && (
              <div style={{ marginTop: 6, color: "var(--ink-text)" }}>
                <div style={{ fontSize: 16 }}>{result.student_name}</div>
                <div className="mono" style={{ fontSize: 12.5, color: "var(--ink-text-dim)", marginTop: 4 }}>
                  {new Date(result.time).toLocaleTimeString()} · {location}
                </div>
              </div>
            )}

            {stage === "error" && (
              <div style={{ marginTop: 6, color: "var(--ink-text-dim)", fontSize: 13, maxWidth: 320 }}>{errorMsg}</div>
            )}

            {stage === "scanning" && (
              <div style={{ marginTop: 6, color: "var(--ink-text-dim)", fontSize: 13 }}>
                Hold your QR code steady in front of the camera
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
