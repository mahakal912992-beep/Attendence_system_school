import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, apiErrorMessage } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const user = await login(email, password);
      navigate(user.role === "admin" || user.role === "teacher" ? "/dashboard" : "/dashboard");
    } catch (err) {
      setError(apiErrorMessage(err, "Could not sign in. Check your email and password."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--ink)" }}>
      <div style={{ width: 380 }}>
        <div style={{ textAlign: "center", marginBottom: 26, color: "var(--ink-text)" }}>
          <div style={{ fontSize: 30 }}>⛩</div>
          <h1 style={{ color: "var(--ink-text)", fontSize: 22, marginTop: 6 }}>Campus Gate</h1>
          <div className="mono" style={{ fontSize: 12, color: "var(--ink-text-dim)" }}>attendance console</div>
        </div>

        <form onSubmit={handleSubmit} className="card" style={{ background: "var(--paper-raised)" }}>
          {error && <div className="banner banner-error">{error}</div>}

          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@school.demo" />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>

          <button className="btn btn-primary" type="submit" disabled={busy} style={{ width: "100%", justifyContent: "center", marginTop: 4 }}>
            {busy ? "Signing in…" : "Sign in"}
          </button>

          <div style={{ marginTop: 18, paddingTop: 14, borderTop: "1px solid var(--paper-line)", fontSize: 12, color: "var(--paper-text-dim)", lineHeight: 1.6 }}>
            <strong>Demo accounts</strong> (password: <code className="mono">DemoPass123!</code>)<br />
            admin@school.demo · teacher@school.demo<br />
            parent1@school.demo · student1@school.demo
          </div>
        </form>
      </div>
    </div>
  );
}
