import { useState } from "react";
import api from "../../api";

function fmt(d) { return d.toISOString().slice(0, 10); }

export default function TeacherExport() {
  const today = new Date();
  const monthAgo = new Date(today.getTime() - 30 * 24 * 3600 * 1000);
  const [start, setStart] = useState(fmt(monthAgo));
  const [end, setEnd] = useState(fmt(today));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleDownload() {
    setBusy(true); setError("");
    try {
      const res = await api.get("/teacher/export", { params: { start, end }, responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `attendance_${start}_${end}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError("Could not generate the export. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <h1>Export attendance</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>Download a CSV for the selected date range.</p>

      <div className="card" style={{ maxWidth: 420 }}>
        {error && <div className="banner banner-error">{error}</div>}
        <div className="field"><label>From</label><input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></div>
        <div className="field"><label>To</label><input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></div>
        <button className="btn btn-primary" onClick={handleDownload} disabled={busy}>
          {busy ? "Preparing…" : "Download CSV"}
        </button>
      </div>
    </div>
  );
}
