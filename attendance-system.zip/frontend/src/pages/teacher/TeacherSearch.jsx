import { useState } from "react";
import api, { apiErrorMessage } from "../../api";

export default function TeacherSearch() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");

  async function handleSearch(e) {
    e.preventDefault();
    if (!q.trim()) return;
    const { data } = await api.get("/teacher/students/search", { params: { q } });
    setResults(data);
  }

  async function openStudent(s) {
    setSelected(s);
    const { data } = await api.get(`/students/${s.student_id}/attendance`);
    setHistory(data);
  }

  return (
    <div>
      <h1>Find a student</h1>
      <form onSubmit={handleSearch} style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, roll number, or class" style={{ flex: 1, padding: "10px 12px", borderRadius: 8, border: "1px solid var(--paper-line)" }} />
        <button className="btn btn-primary" type="submit">Search</button>
      </form>

      {results.length > 0 && (
        <div className="card" style={{ padding: 0, marginBottom: 20 }}>
          <table>
            <thead><tr><th>Name</th><th>Class</th><th>Roll</th><th></th></tr></thead>
            <tbody>
              {results.map((s) => (
                <tr key={s.student_id}>
                  <td>{s.name}</td>
                  <td>{s.class}-{s.section}</td>
                  <td className="mono">{s.roll_number}</td>
                  <td><button className="btn btn-outline btn-sm" onClick={() => openStudent(s)}>View attendance</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <AttendancePanel student={selected} history={history} onCorrected={() => openStudent(selected)} />
      )}
    </div>
  );
}

function AttendancePanel({ student, history, onCorrected }) {
  const [editing, setEditing] = useState(null);
  const [inTime, setInTime] = useState("");
  const [outTime, setOutTime] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  function startEdit(r) {
    setEditing(r.attendance_id);
    setInTime(r.in_time ? r.in_time.slice(0, 16) : "");
    setOutTime(r.out_time ? r.out_time.slice(0, 16) : "");
    setReason("");
    setError(""); setNotice("");
  }

  async function saveCorrection(attendanceId) {
    if (reason.trim().length < 3) { setError("Please enter a reason (min 3 characters)."); return; }
    try {
      await api.patch(`/teacher/attendance/${attendanceId}`, {
        in_time: inTime ? new Date(inTime).toISOString() : null,
        out_time: outTime ? new Date(outTime).toISOString() : null,
        reason,
      });
      setNotice("Attendance record corrected.");
      setEditing(null);
      onCorrected();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div className="card">
      <h3>{student.name} — recent attendance</h3>
      {error && <div className="banner banner-error">{error}</div>}
      {notice && <div className="banner banner-success">{notice}</div>}
      <table>
        <thead><tr><th>Date</th><th>In</th><th>Out</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {history.map((r) => (
            <>
              <tr key={r.date}>
                <td className="mono">{r.date}</td>
                <td className="mono">{r.in_time ? new Date(r.in_time).toLocaleTimeString() : "—"}</td>
                <td className="mono">{r.out_time ? new Date(r.out_time).toLocaleTimeString() : "—"}</td>
                <td><span className={`badge ${r.status === "verified" ? "badge-green" : r.status === "manual_override" ? "badge-blue" : "badge-red"}`}>{r.status.replace(/_/g, " ")}</span></td>
                <td><button className="btn btn-outline btn-sm" onClick={() => startEdit(r)}>Correct</button></td>
              </tr>
              {editing === r.attendance_id && (
                <tr>
                  <td colSpan={5} style={{ background: "var(--paper)" }}>
                    <div style={{ display: "flex", gap: 10, alignItems: "flex-end", flexWrap: "wrap", padding: "10px 0" }}>
                      <div className="field" style={{ margin: 0 }}><label>In time</label><input type="datetime-local" value={inTime} onChange={(e) => setInTime(e.target.value)} /></div>
                      <div className="field" style={{ margin: 0 }}><label>Out time</label><input type="datetime-local" value={outTime} onChange={(e) => setOutTime(e.target.value)} /></div>
                      <div className="field" style={{ margin: 0, flex: 1, minWidth: 200 }}><label>Reason (required)</label><input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Scanner was offline" /></div>
                      <button className="btn btn-primary btn-sm" onClick={() => saveCorrection(r.attendance_id)}>Save</button>
                      <button className="btn btn-outline btn-sm" onClick={() => setEditing(null)}>Cancel</button>
                    </div>
                  </td>
                </tr>
              )}
            </>
          ))}
        </tbody>
      </table>
      <p style={{ fontSize: 12, color: "var(--paper-text-dim)", marginTop: 12 }}>
        Every correction is written to the manual corrections log with your account and the reason given.
      </p>
    </div>
  );
}
