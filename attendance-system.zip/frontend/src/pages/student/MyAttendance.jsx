import { useAuth } from "../../context/AuthContext";
import SelfAttendanceView from "../../components/SelfAttendanceView";

export default function MyAttendance() {
  const { user } = useAuth();
  return <SelfAttendanceView studentId={user?.student_id} title="My attendance" />;
}
