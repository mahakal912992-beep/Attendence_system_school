import { useEffect, useState } from "react";
import api from "../../api";

export default function AuditLog() {
  const [tab, setTab] = useState("edits");
  const [edits, setEdits] = useState([]);
  const [qrLogs, setQrLogs] = useState([]);

  useEffect(() => {
    (async () => {
      const [e, q] = await Promise.all([api.get("/admin/edit-log"), api.get("/admin/qr-audit-log")]);
      setEdits(e.data);
      setQrLogs(q.data);
    })();
  }, []);

  return (
    <div>
      <h1>Audit log</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>Every admin edit and QR action is recorded here — nothing is silent.</p>

      <div style={{ display: "flex", gap: 8, margin: "16px 0" }}>
        {["edits", "qr"].map((t) => (
          <button key={t} className="btn btn-sm" style={{ background: tab === t ? "var(--ink)" : "var(--paper-line)", color: tab === t ? "var(--ink-text)" : "var(--paper-text)" }} onClick={() => setTab(t)}>
            {t === "edits" ? "Admin edits" : "QR actions"}
          </button>
        ))}
      </div>

      <div className="card" style={{ padding: 0 }}>
        {tab === "edits" ? (
          <table>
            <thead><tr><th>Entity</th><th>Reason</th><th>Change</th><th>When</th></tr></thead>
            <tbody>
              {edits.map((l) => (
                <tr key={l.log_id}>
                  <td><span className="badge badge-neutral">{l.entity_type}</span></td>
                  <td style={{ fontSize: 13 }}>{l.reason}</td>
                  <td className="mono" style={{ fontSize: 11, color: "var(--paper-text-dim)", maxWidth: 260 }}>
                    {JSON.stringify(l.old_value)} → {JSON.stringify(l.new_value)}
                  </td>
                  <td className="mono" style={{ fontSize: 12 }}>{new Date(l.timestamp).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table>
            <thead><tr><th>Student</th><th>Action</th><th>Reason</th><th>When</th></tr></thead>
            <tbody>
              {qrLogs.map((l) => (
                <tr key={l.log_id}>
                  <td className="mono" style={{ fontSize: 12 }}>{l.student_id.slice(0, 8)}…</td>
                  <td><span className="badge badge-blue">{l.action}</span></td>
                  <td style={{ fontSize: 13 }}>{l.reason}</td>
                  <td className="mono" style={{ fontSize: 12 }}>{new Date(l.timestamp).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
