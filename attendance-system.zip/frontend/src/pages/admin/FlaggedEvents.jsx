import { useEffect, useState } from "react";
import api, { apiErrorMessage } from "../../api";

export default function FlaggedEvents() {
  const [events, setEvents] = useState([]);
  const [filter, setFilter] = useState("open");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    const params = filter === "all" ? {} : { resolved: filter === "resolved" };
    const { data } = await api.get("/admin/flagged-events", { params });
    setEvents(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, [filter]);

  async function resolve(eventId) {
    const reason = window.prompt("Reason for resolving this flag:");
    if (!reason || reason.trim().length < 3) return;
    try {
      await api.put(`/admin/flagged-events/${eventId}/resolve`, { reason });
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <h1>Flagged events</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>
        Duplicate scans, face mismatches, invalid QR codes, and location anomalies land here for review.
      </p>

      <div style={{ display: "flex", gap: 8, margin: "16px 0" }}>
        {["open", "resolved", "all"].map((f) => (
          <button key={f} className="btn btn-sm" style={{ background: filter === f ? "var(--ink)" : "var(--paper-line)", color: filter === f ? "var(--ink-text)" : "var(--paper-text)" }} onClick={() => setFilter(f)}>
            {f[0].toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {error && <div className="banner banner-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        {loading ? (
          <div style={{ padding: 20 }}>Loading…</div>
        ) : events.length === 0 ? (
          <div style={{ padding: 20, color: "var(--paper-text-dim)" }}>Nothing here.</div>
        ) : (
          <table>
            <thead><tr><th>Type</th><th>Student</th><th>Details</th><th>When</th><th></th></tr></thead>
            <tbody>
              {events.map((e) => (
                <tr key={e.event_id}>
                  <td><span className="badge badge-amber">{e.event_type.replace(/_/g, " ")}</span></td>
                  <td className="mono" style={{ fontSize: 12 }}>{e.student_id ? e.student_id.slice(0, 8) + "…" : "—"}</td>
                  <td className="mono" style={{ fontSize: 11.5, color: "var(--paper-text-dim)" }}>{JSON.stringify(e.details)}</td>
                  <td className="mono" style={{ fontSize: 12 }}>{new Date(e.created_at).toLocaleString()}</td>
                  <td>{!e.resolved && <button className="btn btn-outline btn-sm" onClick={() => resolve(e.event_id)}>Resolve</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
