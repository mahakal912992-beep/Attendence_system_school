import { useEffect, useState } from "react";
import api, { apiErrorMessage } from "../../api";

export default function AcademicCalendar() {
  const [entries, setEntries] = useState([]);
  const [date, setDate] = useState("");
  const [label, setLabel] = useState("");
  const [isHoliday, setIsHoliday] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    const { data } = await api.get("/admin/calendar");
    setEntries(data);
  }
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setError(""); setNotice("");
    try {
      await api.post("/admin/calendar", null, { params: { entry_date: date, label, is_holiday: isHoliday } });
      setNotice("Calendar entry added.");
      setDate(""); setLabel("");
      load();
    } catch (err) {
      setError(apiErrorMessage(err, "Could not add that entry — check the date isn't already used."));
    }
  }

  return (
    <div>
      <h1>Academic calendar</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>Holidays and special days, used to interpret attendance gaps.</p>

      <form onSubmit={handleAdd} className="card" style={{ marginBottom: 20 }}>
        {error && <div className="banner banner-error">{error}</div>}
        {notice && <div className="banner banner-success">{notice}</div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, alignItems: "end" }}>
          <div className="field"><label>Date</label><input type="date" required value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div className="field"><label>Label</label><input required placeholder="Diwali break" value={label} onChange={(e) => setLabel(e.target.value)} /></div>
          <div className="field">
            <label>Type</label>
            <select value={isHoliday ? "holiday" : "event"} onChange={(e) => setIsHoliday(e.target.value === "holiday")}>
              <option value="holiday">Holiday (no attendance expected)</option>
              <option value="event">School event (attendance expected)</option>
            </select>
          </div>
        </div>
        <button className="btn btn-primary" type="submit">Add entry</button>
      </form>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Date</th><th>Label</th><th>Type</th></tr></thead>
          <tbody>
            {entries.map((e) => (
              <tr key={e.date}>
                <td className="mono">{e.date}</td>
                <td>{e.label}</td>
                <td>{e.is_holiday ? <span className="badge badge-amber">Holiday</span> : <span className="badge badge-blue">Event</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
