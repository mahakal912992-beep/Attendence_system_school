import { useEffect, useState } from "react";
import api, { apiErrorMessage } from "../../api";

const emptyForm = { name: "", class: "", section: "", roll_number: "", parent_name: "", parent_phone: "" };

export default function StudentsManage() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await api.get("/students");
    setStudents(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/students", form);
      setShowCreate(false);
      setForm(emptyForm);
      setNotice("Student added.");
      load();
    } catch (err) {
      setError(apiErrorMessage(err, "Could not add student. Check the fields."));
    }
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 20 }}>
        <div>
          <h1>Students</h1>
          <p style={{ color: "var(--paper-text-dim)", margin: 0 }}>{students.length} enrolled</p>
        </div>
        <button className="btn btn-primary" onClick={() => { setShowCreate(true); setError(""); }}>+ Add student</button>
      </div>

      {notice && <div className="banner banner-success">{notice}</div>}

      {showCreate && (
        <form onSubmit={handleCreate} className="card" style={{ marginBottom: 20 }}>
          <h3>New student</h3>
          {error && <div className="banner banner-error">{error}</div>}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field"><label>Full name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="field"><label>Roll number</label><input required value={form.roll_number} onChange={(e) => setForm({ ...form, roll_number: e.target.value })} /></div>
            <div className="field"><label>Class</label><input required value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })} /></div>
            <div className="field"><label>Section</label><input required value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} /></div>
            <div className="field"><label>Parent name</label><input required value={form.parent_name} onChange={(e) => setForm({ ...form, parent_name: e.target.value })} /></div>
            <div className="field"><label>Parent phone (with country code)</label><input required placeholder="+919876543210" value={form.parent_phone} onChange={(e) => setForm({ ...form, parent_phone: e.target.value })} /></div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-primary" type="submit">Save student</button>
            <button className="btn btn-outline" type="button" onClick={() => setShowCreate(false)}>Cancel</button>
          </div>
        </form>
      )}

      <div className="card" style={{ padding: 0 }}>
        {loading ? (
          <div style={{ padding: 20 }}>Loading…</div>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Class</th><th>Roll</th><th>Consent</th><th>QR</th><th></th></tr>
            </thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.student_id}>
                  <td>{s.name}</td>
                  <td>{s.class}-{s.section}</td>
                  <td className="mono">{s.roll_number}</td>
                  <td>{s.biometric_consent ? <span className="badge badge-green">Given</span> : <span className="badge badge-neutral">Not set</span>}</td>
                  <td>{s.has_active_qr ? <span className="badge badge-blue">Active</span> : <span className="badge badge-neutral">None</span>}</td>
                  <td><button className="btn btn-outline btn-sm" onClick={() => setSelected(s)}>Manage</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selected && (
        <StudentDetail
          student={selected}
          onClose={() => setSelected(null)}
          onChanged={() => { load(); }}
        />
      )}
    </div>
  );
}

function StudentDetail({ student, onClose, onChanged }) {
  const [s, setS] = useState(student);
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [qr, setQr] = useState(null);
  const [photoFile, setPhotoFile] = useState(null);
  const [busy, setBusy] = useState(false);

  async function refreshStudent() {
    const { data } = await api.get(`/students/${s.student_id}`);
    setS(data);
    onChanged();
  }

  function requireReason() {
    if (reason.trim().length < 3) {
      setError("Please enter a reason (min 3 characters) for this change.");
      return false;
    }
    return true;
  }

  async function handleConsentToggle() {
    if (!requireReason()) return;
    setError(""); setBusy(true);
    try {
      await api.put(`/students/${s.student_id}/consent`, { consent: !s.biometric_consent, reason });
      setNotice("Consent updated."); setReason("");
      await refreshStudent();
    } catch (err) { setError(apiErrorMessage(err)); } finally { setBusy(false); }
  }

  async function handleGenerateQr() {
    if (!requireReason()) return;
    setError(""); setBusy(true);
    try {
      const { data } = await api.post(`/students/${s.student_id}/generate-qr`, { reason });
      setQr(data); setNotice("QR code generated."); setReason("");
      await refreshStudent();
    } catch (err) { setError(apiErrorMessage(err)); } finally { setBusy(false); }
  }

  async function handleRevokeQr() {
    if (!requireReason()) return;
    setError(""); setBusy(true);
    try {
      await api.post(`/students/${s.student_id}/revoke-qr`, { reason });
      setQr(null); setNotice("QR code revoked."); setReason("");
      await refreshStudent();
    } catch (err) { setError(apiErrorMessage(err)); } finally { setBusy(false); }
  }

  async function handlePhotoUpload() {
    if (!photoFile) { setError("Choose a photo file first."); return; }
    setError(""); setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", photoFile);
      await api.post(`/students/${s.student_id}/photo`, fd, { headers: { "Content-Type": "multipart/form-data" } });
      setNotice("Registered photo updated. Face embedding regenerated.");
      await refreshStudent();
    } catch (err) { setError(apiErrorMessage(err, "Could not process that image.")); } finally { setBusy(false); }
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(18,24,43,0.4)", display: "grid", placeItems: "center", zIndex: 50 }} onClick={onClose}>
      <div className="card" style={{ width: 520, maxHeight: "85vh", overflowY: "auto" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <h2 style={{ marginBottom: 2 }}>{s.name}</h2>
            <div style={{ color: "var(--paper-text-dim)", fontSize: 13 }}>{s.class}-{s.section} · Roll {s.roll_number}</div>
          </div>
          <button className="btn btn-outline btn-sm" onClick={onClose}>Close</button>
        </div>

        <div style={{ fontSize: 13, color: "var(--paper-text-dim)", margin: "10px 0 16px" }}>
          Parent: {s.parent_name} · {s.parent_phone_masked}
        </div>

        {error && <div className="banner banner-error">{error}</div>}
        {notice && <div className="banner banner-success">{notice}</div>}

        <div className="field">
          <label>Reason for change (required for any edit below)</label>
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Parent requested update" />
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
          <button className="btn btn-outline btn-sm" disabled={busy} onClick={handleConsentToggle}>
            {s.biometric_consent ? "Withdraw biometric consent" : "Grant biometric consent"}
          </button>
          {s.has_active_qr ? (
            <>
              <button className="btn btn-outline btn-sm" disabled={busy} onClick={handleGenerateQr}>Regenerate QR</button>
              <button className="btn btn-danger btn-sm" disabled={busy} onClick={handleRevokeQr}>Revoke QR</button>
            </>
          ) : (
            <button className="btn btn-outline btn-sm" disabled={busy} onClick={handleGenerateQr}>Generate QR</button>
          )}
        </div>

        {qr && (
          <div style={{ textAlign: "center", marginBottom: 18, padding: 14, border: "1px dashed var(--paper-line)", borderRadius: 8 }}>
            <img src={`data:image/png;base64,${qr.qr_image_base64}`} alt="QR code" width={160} height={160} />
            <div className="mono" style={{ fontSize: 11, color: "var(--paper-text-dim)", marginTop: 6 }}>token: {qr.qr_token_id.slice(0, 8)}…</div>
          </div>
        )}

        <div className="field">
          <label>Update registered photo (used for face verification)</label>
          <input type="file" accept="image/*" onChange={(e) => setPhotoFile(e.target.files[0])} />
        </div>
        <button className="btn btn-outline btn-sm" disabled={busy} onClick={handlePhotoUpload}>Upload photo</button>
      </div>
    </div>
  );
}
