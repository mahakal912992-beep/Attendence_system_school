import { useEffect, useState } from "react";
import api, { apiErrorMessage } from "../../api";

export default function Settings() {
  const [settings, setSettings] = useState({});
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    const { data } = await api.get("/admin/settings");
    setSettings(data);
  }
  useEffect(() => { load(); }, []);

  async function handleSave(e) {
    e.preventDefault();
    setError(""); setNotice("");
    try {
      await api.put("/admin/settings", { key, value, reason });
      setNotice(`Setting "${key}" updated.`);
      setKey(""); setValue(""); setReason("");
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <h1>Settings</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>System-wide configuration, versioned in the admin edit log.</p>

      <div className="card" style={{ marginBottom: 20 }}>
        <h3>Current values</h3>
        {Object.keys(settings).length === 0 ? (
          <p style={{ color: "var(--paper-text-dim)", fontSize: 13.5 }}>No settings configured yet.</p>
        ) : (
          <table>
            <tbody>
              {Object.entries(settings).map(([k, v]) => (
                <tr key={k}><td className="mono">{k}</td><td className="mono">{v}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <form className="card" onSubmit={handleSave}>
        <h3>Update a setting</h3>
        {error && <div className="banner banner-error">{error}</div>}
        {notice && <div className="banner banner-success">{notice}</div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div className="field"><label>Key</label><input required placeholder="in_out_cutoff_time" value={key} onChange={(e) => setKey(e.target.value)} /></div>
          <div className="field"><label>Value</label><input required placeholder="09:00" value={value} onChange={(e) => setValue(e.target.value)} /></div>
        </div>
        <div className="field"><label>Reason</label><input required value={reason} onChange={(e) => setReason(e.target.value)} /></div>
        <button className="btn btn-primary" type="submit">Save setting</button>
      </form>
    </div>
  );
}
