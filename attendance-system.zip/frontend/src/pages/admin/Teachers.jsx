import { useEffect, useState } from "react";
import api, { apiErrorMessage } from "../../api";

export default function Teachers() {
  const [teachers, setTeachers] = useState([]);
  const [form, setForm] = useState({ full_name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    const { data } = await api.get("/admin/teachers");
    setTeachers(data);
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/admin/teachers", form);
      setForm({ full_name: "", email: "", password: "" });
      setNotice("Teacher account created.");
      load();
    } catch (err) {
      setError(apiErrorMessage(err, "Could not create teacher account."));
    }
  }

  async function toggleActive(t) {
    const reason = window.prompt(`Reason for ${t.is_active ? "deactivating" : "reactivating"} ${t.full_name}:`);
    if (!reason || reason.trim().length < 3) return;
    await api.patch(`/admin/teachers/${t.id}`, { is_active: !t.is_active, reason });
    load();
  }

  return (
    <div>
      <h1>Teachers</h1>
      {notice && <div className="banner banner-success">{notice}</div>}

      <form onSubmit={handleCreate} className="card" style={{ marginBottom: 20 }}>
        <h3>Add teacher</h3>
        {error && <div className="banner banner-error">{error}</div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
          <div className="field"><label>Full name</label><input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
          <div className="field"><label>Email</label><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div className="field"><label>Temporary password</label><input required type="text" minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        </div>
        <button className="btn btn-primary" type="submit">Create account</button>
      </form>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {teachers.map((t) => (
              <tr key={t.id}>
                <td>{t.full_name}</td>
                <td className="mono" style={{ fontSize: 12.5 }}>{t.email}</td>
                <td>{t.is_active ? <span className="badge badge-green">Active</span> : <span className="badge badge-neutral">Inactive</span>}</td>
                <td><button className="btn btn-outline btn-sm" onClick={() => toggleActive(t)}>{t.is_active ? "Deactivate" : "Reactivate"}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
