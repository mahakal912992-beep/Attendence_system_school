import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../api";
import StatCard from "../../components/StatCard";

export default function AdminOverview() {
  const [summary, setSummary] = useState(null);
  const [flags, setFlags] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [s, f] = await Promise.all([
        api.get("/analytics/summary"),
        api.get("/admin/flagged-events", { params: { resolved: false } }),
      ]);
      setSummary(s.data);
      setFlags(f.data.slice(0, 6));
      setLoading(false);
    })();
  }, []);

  if (loading) return <div>Loading…</div>;

  return (
    <div>
      <h1>Overview</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8, marginBottom: 24 }}>Today at a glance.</p>

      <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 28 }}>
        <StatCard label="Enrolled students" value={summary.total_students} />
        <StatCard label="Present today" value={summary.present_today} tone="green" />
        <StatCard label="Absent today" value={summary.absent_today} tone="red" />
        <StatCard label="Late arrivals" value={summary.late_arrivals_today} tone="amber" />
        <StatCard label="30-day attendance rate" value={`${summary.attendance_rate_30d}%`} tone="blue" />
        <StatCard label="Open flagged events" value={summary.open_flagged_events} tone={summary.open_flagged_events > 0 ? "red" : "neutral"} />
      </div>

      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <h3 style={{ margin: 0 }}>Recent flagged events</h3>
          <Link to="/dashboard/flagged" style={{ fontSize: 13, color: "var(--blue)", textDecoration: "none", fontWeight: 600 }}>
            View all →
          </Link>
        </div>
        {flags.length === 0 ? (
          <p style={{ color: "var(--paper-text-dim)", fontSize: 13.5 }}>No open flagged events. Nothing needs review right now.</p>
        ) : (
          <table>
            <thead>
              <tr><th>Type</th><th>Student</th><th>When</th></tr>
            </thead>
            <tbody>
              {flags.map((f) => (
                <tr key={f.event_id}>
                  <td><span className="badge badge-amber">{f.event_type.replace(/_/g, " ")}</span></td>
                  <td className="mono" style={{ fontSize: 12 }}>{f.student_id || "—"}</td>
                  <td className="mono" style={{ fontSize: 12 }}>{new Date(f.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
