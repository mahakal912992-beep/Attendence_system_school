import { useEffect, useState } from "react";
import api from "../api";

export default function SelfAttendanceView({ studentId, title }) {
  const [student, setStudent] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!studentId) return;
    (async () => {
      try {
        const [s, h] = await Promise.all([
          api.get(`/students/${studentId}`),
          api.get(`/students/${studentId}/attendance`),
        ]);
        setStudent(s.data);
        setHistory(h.data);
      } catch {
        setError("Could not load attendance records.");
      }
    })();
  }, [studentId]);

  if (!studentId) return <div className="banner banner-error">No linked student record found for this account.</div>;
  if (error) return <div className="banner banner-error">{error}</div>;
  if (!student) return <div>Loading…</div>;

  const presentDays = history.filter((r) => r.in_time).length;
  const lateDays = history.filter((r) => r.in_time && new Date(r.in_time).getHours() >= 9).length;

  return (
    <div>
      <h1>{title}</h1>
      <p style={{ color: "var(--paper-text-dim)", marginTop: -8 }}>
        {student.name} · {student.class}-{student.section} · Roll {student.roll_number}
      </p>

      <div style={{ display: "flex", gap: 14, margin: "20px 0" }}>
        <div className="card" style={{ minWidth: 140 }}>
          <div style={{ fontSize: 11.5, color: "var(--paper-text-dim)", fontWeight: 600, textTransform: "uppercase" }}>Days present (recent)</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 700 }}>{presentDays}</div>
        </div>
        <div className="card" style={{ minWidth: 140 }}>
          <div style={{ fontSize: 11.5, color: "var(--paper-text-dim)", fontWeight: 600, textTransform: "uppercase" }}>Late arrivals</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 700, color: "#8A5A16" }}>{lateDays}</div>
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Date</th><th>In</th><th>Out</th><th>Status</th></tr></thead>
          <tbody>
            {history.length === 0 ? (
              <tr><td colSpan={4} style={{ padding: 20, color: "var(--paper-text-dim)" }}>No attendance records yet.</td></tr>
            ) : history.map((r) => (
              <tr key={r.date}>
                <td className="mono">{r.date}</td>
                <td className="mono">{r.in_time ? new Date(r.in_time).toLocaleTimeString() : "—"}</td>
                <td className="mono">{r.out_time ? new Date(r.out_time).toLocaleTimeString() : "—"}</td>
                <td><span className={`badge ${r.status === "verified" ? "badge-green" : r.status === "manual_override" ? "badge-blue" : "badge-red"}`}>{r.status.replace(/_/g, " ")}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
