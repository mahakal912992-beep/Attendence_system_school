import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV = {
  admin: [
    { to: "/dashboard", label: "Overview", end: true },
    { to: "/dashboard/students", label: "Students" },
    { to: "/dashboard/flagged", label: "Flagged events" },
    { to: "/dashboard/teachers", label: "Teachers" },
    { to: "/dashboard/calendar", label: "Academic calendar" },
    { to: "/dashboard/audit", label: "Audit log" },
    { to: "/dashboard/settings", label: "Settings" },
  ],
  teacher: [
    { to: "/dashboard", label: "Find a student", end: true },
    { to: "/dashboard/export", label: "Export attendance" },
  ],
  parent: [{ to: "/dashboard", label: "My child", end: true }],
  student: [{ to: "/dashboard", label: "My attendance", end: true }],
};

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = NAV[user?.role] || [];

  async function handleLogout() {
    await logout();
    navigate("/login");
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <aside
        style={{
          width: 232,
          background: "var(--ink)",
          color: "var(--ink-text)",
          padding: "24px 16px",
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
        }}
      >
        <div style={{ padding: "0 8px 28px" }}>
          <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 17, letterSpacing: "-0.01em" }}>
            ⛩ Campus Gate
          </div>
          <div className="mono" style={{ fontSize: 11, color: "var(--ink-text-dim)", marginTop: 2 }}>
            attendance console
          </div>
        </div>

        <nav style={{ display: "flex", flexDirection: "column", gap: 2, flex: 1 }}>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              style={({ isActive }) => ({
                padding: "9px 12px",
                borderRadius: 8,
                fontSize: 13.5,
                fontWeight: 600,
                textDecoration: "none",
                color: isActive ? "var(--ink)" : "var(--ink-text)",
                background: isActive ? "var(--ink-text)" : "transparent",
              })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ borderTop: "1px solid var(--ink-line)", paddingTop: 14, marginTop: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>{user?.full_name}</div>
          <div className="mono" style={{ fontSize: 11, color: "var(--ink-text-dim)", marginBottom: 10 }}>
            {user?.role}
          </div>
          {(user?.role === "admin" || user?.role === "teacher") && (
            <NavLink to="/scan" style={{ display: "block", fontSize: 12.5, color: "var(--amber)", marginBottom: 10, textDecoration: "none" }}>
              → Open scan kiosk
            </NavLink>
          )}
          <button className="btn btn-outline btn-sm" style={{ width: "100%", color: "var(--ink-text)", borderColor: "var(--ink-line)" }} onClick={handleLogout}>
            Log out
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, padding: "28px 36px", maxWidth: 1180 }}>{children}</main>
    </div>
  );
}
