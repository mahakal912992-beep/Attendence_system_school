export default function StatCard({ label, value, tone = "neutral" }) {
  const colors = {
    neutral: "var(--paper-text)",
    green: "var(--green)",
    amber: "#8A5A16",
    red: "var(--red)",
    blue: "var(--blue)",
  };
  return (
    <div className="card" style={{ minWidth: 150 }}>
      <div style={{ fontSize: 11.5, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--paper-text-dim)", fontWeight: 600, marginBottom: 8 }}>
        {label}
      </div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: 30, fontWeight: 700, color: colors[tone] }}>{value}</div>
    </div>
  );
}
