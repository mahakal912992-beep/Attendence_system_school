import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";

import Login from "./pages/Login";
import ScanKiosk from "./pages/ScanKiosk";

import AdminOverview from "./pages/admin/AdminOverview";
import StudentsManage from "./pages/admin/StudentsManage";
import FlaggedEvents from "./pages/admin/FlaggedEvents";
import Teachers from "./pages/admin/Teachers";
import AuditLog from "./pages/admin/AuditLog";
import Settings from "./pages/admin/Settings";
import AcademicCalendar from "./pages/admin/AcademicCalendar";

import TeacherSearch from "./pages/teacher/TeacherSearch";
import TeacherExport from "./pages/teacher/TeacherExport";

import ChildAttendance from "./pages/parent/ChildAttendance";
import MyAttendance from "./pages/student/MyAttendance";

function DashboardRoot() {
  const { user } = useAuth();
  if (user?.role === "admin") return <AdminOverview />;
  if (user?.role === "teacher") return <TeacherSearch />;
  if (user?.role === "parent") return <ChildAttendance />;
  if (user?.role === "student") return <MyAttendance />;
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/scan"
            element={
              <ProtectedRoute roles={["admin", "teacher"]}>
                <ScanKiosk />
              </ProtectedRoute>
            }
          />

          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Layout>
                  <DashboardRoot />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/students"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><StudentsManage /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/flagged"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><FlaggedEvents /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/teachers"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><Teachers /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/audit"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><AuditLog /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/settings"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><Settings /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/calendar"
            element={
              <ProtectedRoute roles={["admin"]}>
                <Layout><AcademicCalendar /></Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/export"
            element={
              <ProtectedRoute roles={["teacher", "admin"]}>
                <Layout><TeacherExport /></Layout>
              </ProtectedRoute>
            }
          />

          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
