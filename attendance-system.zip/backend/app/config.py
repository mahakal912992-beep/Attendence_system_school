"""
Centralized configuration. Every value that could differ between
development / staging / production, or that is secret, is read from the
environment (via .env in local dev) and NEVER hardcoded here.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: str = "development"

    database_url: str = "sqlite:///./attendance_dev.db"

    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 7

    qr_signing_secret: str

    field_encryption_key: str

    allowed_origins: str = "http://localhost:5173"

    face_provider: str = "mock"
    face_match_threshold: float = 0.75

    whatsapp_provider: str = "mock"
    whatsapp_api_token: str = ""
    whatsapp_phone_number_id: str = ""
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_whatsapp_from: str = ""

    login_rate_limit: str = "10/minute"
    scan_rate_limit: str = "3/minute"

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def allowed_origins_list(self) -> List[str]:
        return [o.strip() for o in self.allowed_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
