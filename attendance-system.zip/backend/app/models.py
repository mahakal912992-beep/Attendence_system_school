import enum
import uuid
from datetime import datetime

from sqlalchemy import (Boolean, Column, Date, DateTime, Enum, ForeignKey,
                         Integer, String, Text, JSON, UniqueConstraint)
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid() -> str:
    return str(uuid.uuid4())


class Role(str, enum.Enum):
    student = "student"
    parent = "parent"
    teacher = "teacher"
    admin = "admin"


class VerificationStatus(str, enum.Enum):
    verified = "verified"
    manual_override = "manual_override"
    flagged_fraud = "flagged_fraud"


class QRAction(str, enum.Enum):
    generated = "generated"
    regenerated = "regenerated"
    revoked = "revoked"


class FlaggedEventType(str, enum.Enum):
    duplicate_scan = "duplicate_scan"
    face_mismatch = "face_mismatch"
    invalid_qr = "invalid_qr"
    location_anomaly = "location_anomaly"
    liveness_failed = "liveness_failed"


class NotificationChannel(str, enum.Enum):
    whatsapp = "whatsapp"


class NotificationStatus(str, enum.Enum):
    sent = "sent"
    failed = "failed"
    pending = "pending"


class EntityType(str, enum.Enum):
    student = "student"
    attendance = "attendance"
    teacher = "teacher"
    settings = "settings"
    parent_contact = "parent_contact"


# ---------------------------------------------------------------- Users ----
class User(Base):
    """
    Auth identities for every role. Students/Parents/Teachers/Admins all log
    in through this table; role is verified server-side on every request,
    never trusted from a client-sent claim without checking this row.
    """
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_uuid)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(Role), nullable=False)
    full_name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

    # Links a user identity to a domain row depending on role
    student_id = Column(String, ForeignKey("students.student_id"), nullable=True)
    parent_of_student_id = Column(String, ForeignKey("students.student_id"), nullable=True)

    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    token_hash = Column(String, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    revoked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# -------------------------------------------------------------- Students ---
class Student(Base):
    __tablename__ = "students"

    student_id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String, nullable=False)
    klass = Column("class", String, nullable=False)
    section = Column(String, nullable=False)
    roll_number = Column(String, nullable=False)
    parent_name = Column(String, nullable=False)

    # ENCRYPTED at rest via app.crypto before being written here
    parent_phone_encrypted = Column(String, nullable=False)

    # ENCRYPTED embedding vector, never a raw match image
    face_embedding_encrypted = Column(Text, nullable=True)

    qr_token_id = Column(String, nullable=True)  # references active signed token id, not raw payload
    photo_url = Column(String, nullable=True)
    biometric_consent = Column(Boolean, default=False)
    active = Column(Boolean, default=True)

    created_at = Column(DateTime, default=datetime.utcnow)


class Attendance(Base):
    __tablename__ = "attendance"
    __table_args__ = (UniqueConstraint("student_id", "date", name="uq_student_date"),)

    attendance_id = Column(String, primary_key=True, default=gen_uuid)
    student_id = Column(String, ForeignKey("students.student_id"), nullable=False)
    date = Column(Date, nullable=False)
    in_time = Column(DateTime, nullable=True)
    out_time = Column(DateTime, nullable=True)
    location = Column(String, nullable=True)
    verification_status = Column(Enum(VerificationStatus), default=VerificationStatus.verified)
    device_id = Column(String, nullable=True)


class QRAuditLog(Base):
    __tablename__ = "qr_audit_log"

    log_id = Column(String, primary_key=True, default=gen_uuid)
    student_id = Column(String, ForeignKey("students.student_id"), nullable=False)
    generated_by = Column(String, ForeignKey("users.id"), nullable=False)
    action = Column(Enum(QRAction), nullable=False)
    reason = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)


class FlaggedEvent(Base):
    __tablename__ = "flagged_events"

    event_id = Column(String, primary_key=True, default=gen_uuid)
    student_id = Column(String, ForeignKey("students.student_id"), nullable=True)
    event_type = Column(Enum(FlaggedEventType), nullable=False)
    details = Column(JSON, nullable=True)
    resolved = Column(Boolean, default=False)
    resolved_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class NotificationLog(Base):
    __tablename__ = "notifications_log"

    log_id = Column(String, primary_key=True, default=gen_uuid)
    student_id = Column(String, ForeignKey("students.student_id"), nullable=False)
    channel = Column(Enum(NotificationChannel), default=NotificationChannel.whatsapp)
    status = Column(Enum(NotificationStatus), default=NotificationStatus.pending)
    attempt_count = Column(Integer, default=0)
    last_error = Column(String, nullable=True)
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AdminEditLog(Base):
    __tablename__ = "admin_edit_log"

    log_id = Column(String, primary_key=True, default=gen_uuid)
    admin_id = Column(String, ForeignKey("users.id"), nullable=False)
    entity_type = Column(Enum(EntityType), nullable=False)
    entity_id = Column(String, nullable=False)
    old_value = Column(JSON, nullable=True)
    new_value = Column(JSON, nullable=True)
    reason = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)


class ManualCorrectionLog(Base):
    __tablename__ = "manual_corrections_log"

    log_id = Column(String, primary_key=True, default=gen_uuid)
    attendance_id = Column(String, ForeignKey("attendance.attendance_id"), nullable=False)
    corrected_by = Column(String, ForeignKey("users.id"), nullable=False)
    old_value = Column(JSON, nullable=True)
    new_value = Column(JSON, nullable=True)
    reason = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class ScanEvent(Base):
    """Every scan attempt (used for rate-limiting / anomaly detection), independent
    of whether it resulted in a saved attendance row."""
    __tablename__ = "scan_events"

    id = Column(String, primary_key=True, default=gen_uuid)
    student_id = Column(String, ForeignKey("students.student_id"), nullable=True)
    device_id = Column(String, nullable=True)
    ip_address = Column(String, nullable=True)
    outcome = Column(String, nullable=False)  # success | qr_invalid | face_mismatch | rate_limited | liveness_failed
    created_at = Column(DateTime, default=datetime.utcnow)


class SystemSettings(Base):
    __tablename__ = "system_settings"

    key = Column(String, primary_key=True)
    value = Column(String, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow)


class AcademicCalendarEntry(Base):
    __tablename__ = "academic_calendar"

    id = Column(String, primary_key=True, default=gen_uuid)
    date = Column(Date, nullable=False, unique=True)
    label = Column(String, nullable=False)
    is_holiday = Column(Boolean, default=True)
