import logging
import sys


def configure_logging():
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger("attendance")
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    root.propagate = False
    return root
