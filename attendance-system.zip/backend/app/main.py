import logging
import uuid

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi.errors import RateLimitExceeded
from starlette.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.config import get_settings
from app.database import Base, engine
from app.dependencies import AppError
from app.logging_config import configure_logging
from app.middleware import HTTPSRedirectInProdMiddleware, SecurityHeadersMiddleware
from app.rate_limit import limiter
from app.routers import admin, analytics, auth, scan, students, teacher

configure_logging()
logger = logging.getLogger("attendance.main")
settings = get_settings()

Base.metadata.create_all(bind=engine)


app = FastAPI(title="Smart School Attendance System", version="1.0.0")
app.state.limiter = limiter

# ---------------------------------------------------------------- CORS -----
# Never "*" in production - only known frontend origins from config.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(HTTPSRedirectInProdMiddleware)

app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


# --------------------------------------------------------- Error handling --
@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    return JSONResponse(status_code=exc.status_code, content=exc.detail)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    # Generic message to the client; full field errors only in server logs.
    logger.info("validation_error path=%s errors=%s", request.url.path, exc.errors())
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"success": False, "error_code": "VALIDATION_ERROR", "message": "One or more fields are invalid."},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    if isinstance(exc.detail, dict):
        return JSONResponse(status_code=exc.status_code, content=exc.detail)
    return JSONResponse(status_code=exc.status_code, content={"success": False, "error_code": "ERROR", "message": str(exc.detail)})


@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        content={"success": False, "error_code": "RATE_LIMITED", "message": "Too many requests. Please slow down."},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Never leak stack traces / internal file paths to the client. Full
    # detail goes to server logs only, tagged with a correlation id.
    error_id = str(uuid.uuid4())
    logger.exception("unhandled_error error_id=%s path=%s", error_id, request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "error_code": "INTERNAL_ERROR", "message": f"Something went wrong. Reference: {error_id}"},
    )


# -------------------------------------------------------------- Routers ----
app.include_router(auth.router)
app.include_router(students.router)
app.include_router(scan.router)
app.include_router(admin.router)
app.include_router(teacher.router)
app.include_router(analytics.router)


@app.get("/health")
def health():
    """Explicitly public - the one endpoint that doesn't require auth."""
    return {"status": "ok"}
