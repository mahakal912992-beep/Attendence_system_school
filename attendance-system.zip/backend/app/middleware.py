from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.config import get_settings

settings = get_settings()


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'"
        )
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
        return response


class HTTPSRedirectInProdMiddleware(BaseHTTPMiddleware):
    """Rejects plain HTTP in production (behind a TLS-terminating proxy,
    this checks X-Forwarded-Proto since the app itself sees HTTP)."""

    async def dispatch(self, request: Request, call_next):
        if settings.is_production:
            proto = request.headers.get("x-forwarded-proto", request.url.scheme)
            if proto != "https":
                from starlette.responses import JSONResponse

                return JSONResponse(
                    status_code=400,
                    content={"success": False, "error_code": "HTTPS_REQUIRED", "message": "HTTPS is required."},
                )
        response = await call_next(request)
        return response
