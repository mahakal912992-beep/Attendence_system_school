from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import require_teacher_or_admin
from app.models import Attendance, FlaggedEvent, Student, SystemSettings, VerificationStatus
from app.schemas import AnalyticsSummary

router = APIRouter(prefix="/analytics", tags=["analytics"])

DEFAULT_LATE_CUTOFF_HOUR = 9  # used if no admin override is set in system_settings


def _late_cutoff_hour(db: Session) -> int:
    setting = db.query(SystemSettings).filter(SystemSettings.key == "in_out_cutoff_time").first()
    if setting and ":" in setting.value:
        try:
            return int(setting.value.split(":")[0])
        except ValueError:
            pass
    return DEFAULT_LATE_CUTOFF_HOUR


@router.get("/summary", response_model=AnalyticsSummary)
def summary(db: Session = Depends(get_db), _=Depends(require_teacher_or_admin)):
    today = date.today()
    total_students = db.query(func.count(Student.student_id)).filter(Student.active.is_(True)).scalar() or 0

    todays_records = db.query(Attendance).filter(Attendance.date == today).all()
    present_today = len(todays_records)
    cutoff_hour = _late_cutoff_hour(db)
    late_arrivals_today = sum(1 for r in todays_records if r.in_time and r.in_time.hour >= cutoff_hour)
    absent_today = max(total_students - present_today, 0)

    window_start = today - timedelta(days=30)
    window_records = db.query(Attendance).filter(Attendance.date >= window_start, Attendance.date <= today).count()
    possible = total_students * 30 if total_students else 1
    attendance_rate_30d = round(min(window_records / possible, 1.0) * 100, 1)

    open_flags = db.query(func.count(FlaggedEvent.event_id)).filter(FlaggedEvent.resolved.is_(False)).scalar() or 0

    return AnalyticsSummary(
        total_students=total_students,
        present_today=present_today,
        absent_today=absent_today,
        late_arrivals_today=late_arrivals_today,
        attendance_rate_30d=attendance_rate_30d,
        open_flagged_events=open_flags,
    )
