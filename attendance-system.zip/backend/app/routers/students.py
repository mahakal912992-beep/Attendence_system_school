import logging
import os
import uuid
from datetime import date

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.audit import log_admin_edit
from app.crypto import decrypt_text, encrypt_text, mask_phone
from app.database import get_db
from app.dependencies import AppError, require_admin, require_any_authenticated, require_teacher_or_admin
from app.models import (Attendance, EntityType, QRAction, QRAuditLog, Student,
                         User)
from app.schemas import (ConsentUpdate, QRGenerateRequest, QRGenerateResponse,
                          QRRevokeRequest, StudentCreate, StudentOut, StudentUpdate)
from app.services import face_service, qr_service

logger = logging.getLogger("attendance.students")
router = APIRouter(prefix="/students", tags=["students"])

PHOTO_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "uploads", "photos")
os.makedirs(PHOTO_DIR, exist_ok=True)


def _to_out(s: Student) -> StudentOut:
    return StudentOut(
        student_id=s.student_id,
        name=s.name,
        klass=s.klass,
        section=s.section,
        roll_number=s.roll_number,
        parent_name=s.parent_name,
        parent_phone_masked=mask_phone(decrypt_text(s.parent_phone_encrypted)),
        photo_url=s.photo_url,
        biometric_consent=s.biometric_consent,
        active=s.active,
        has_active_qr=bool(s.qr_token_id),
    )


def _get_student_or_404(db: Session, student_id: str) -> Student:
    s = db.query(Student).filter(Student.student_id == student_id).first()
    if not s:
        raise AppError(status.HTTP_404_NOT_FOUND, "STUDENT_NOT_FOUND", "Student not found.")
    return s


# --------------------------------------------------------------- Admin CRUD
@router.post("", response_model=StudentOut, status_code=status.HTTP_201_CREATED)
def create_student(body: StudentCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    student = Student(
        name=body.name,
        klass=body.klass,
        section=body.section,
        roll_number=body.roll_number,
        parent_name=body.parent_name,
        parent_phone_encrypted=encrypt_text(body.parent_phone),
    )
    db.add(student)
    db.flush()
    log_admin_edit(db, admin.id, EntityType.student, student.student_id, None, body.model_dump(by_alias=True), "Student created")
    db.commit()
    return _to_out(student)


@router.get("", response_model=list[StudentOut])
def list_students(db: Session = Depends(get_db), _: User = Depends(require_teacher_or_admin)):
    return [_to_out(s) for s in db.query(Student).order_by(Student.name).all()]


@router.get("/{student_id}", response_model=StudentOut)
def get_student(student_id: str, db: Session = Depends(get_db), user: User = Depends(require_any_authenticated)):
    s = _get_student_or_404(db, student_id)
    # Students/parents may only view their own linked record
    if user.role.value == "student" and user.student_id != student_id:
        raise AppError(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "You can only view your own record.")
    if user.role.value == "parent" and user.parent_of_student_id != student_id:
        raise AppError(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "You can only view your own child's record.")
    return _to_out(s)


@router.patch("/{student_id}", response_model=StudentOut)
def update_student(student_id: str, body: StudentUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    s = _get_student_or_404(db, student_id)
    old_value = _to_out(s).model_dump(by_alias=True)

    changes = body.model_dump(exclude_unset=True, exclude={"reason"}, by_alias=True)
    if "parent_phone" in changes:
        s.parent_phone_encrypted = encrypt_text(changes.pop("parent_phone"))
    for field, value in changes.items():
        attr = "klass" if field == "class" else field
        setattr(s, attr, value)

    db.flush()
    log_admin_edit(db, admin.id, EntityType.student, student_id, old_value, _to_out(s).model_dump(by_alias=True), body.reason)
    db.commit()
    return _to_out(s)


@router.post("/{student_id}/photo", response_model=StudentOut)
def upload_student_photo(
    student_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    s = _get_student_or_404(db, student_id)
    raw = file.file.read()

    import base64

    b64 = base64.b64encode(raw).decode()
    try:
        decoded = face_service.decode_and_validate_image(b64)
    except face_service.ImageValidationError as e:
        raise AppError(status.HTTP_400_BAD_REQUEST, "INVALID_IMAGE", str(e))

    filename = f"{uuid.uuid4()}.png"
    path = os.path.join(PHOTO_DIR, filename)
    with open(path, "wb") as f:
        f.write(decoded.raw_bytes)

    embedding = face_service.generate_embedding(decoded)
    from app.crypto import encrypt_vector

    old_value = {"photo_url": s.photo_url}
    s.photo_url = f"/uploads/photos/{filename}"
    s.face_embedding_encrypted = encrypt_vector(embedding)
    db.flush()
    log_admin_edit(db, admin.id, EntityType.student, student_id, old_value, {"photo_url": s.photo_url}, "Registered photo updated")
    db.commit()
    return _to_out(s)


@router.put("/{student_id}/consent", response_model=StudentOut)
def update_consent(student_id: str, body: ConsentUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    s = _get_student_or_404(db, student_id)
    old_value = {"biometric_consent": s.biometric_consent}
    s.biometric_consent = body.consent
    db.flush()
    log_admin_edit(db, admin.id, EntityType.student, student_id, old_value, {"biometric_consent": body.consent}, body.reason)
    db.commit()
    return _to_out(s)


@router.delete("/{student_id}/biometric-data")
def purge_biometric_data(student_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    """Data-deletion support: student leaves school -> purge biometric + QR data."""
    s = _get_student_or_404(db, student_id)
    old_value = {"face_embedding_present": bool(s.face_embedding_encrypted), "qr_token_id": s.qr_token_id}
    s.face_embedding_encrypted = None
    s.qr_token_id = None
    s.biometric_consent = False
    db.flush()
    log_admin_edit(db, admin.id, EntityType.student, student_id, old_value, {"face_embedding_present": False, "qr_token_id": None}, "Biometric + QR data purged on request")
    db.commit()
    return {"success": True, "message": "Biometric and QR data purged."}


# ----------------------------------------------------------------- QR mgmt
@router.post("/{student_id}/generate-qr", response_model=QRGenerateResponse)
def generate_qr(student_id: str, body: QRGenerateRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    """Admin-only, enforced here via require_admin - not just hidden in the UI."""
    s = _get_student_or_404(db, student_id)

    action = QRAction.regenerated if s.qr_token_id else QRAction.generated
    payload_jwt, token_id = qr_service.issue_qr_token(student_id)

    s.qr_token_id = token_id
    db.add(QRAuditLog(student_id=student_id, generated_by=admin.id, action=action, reason=body.reason))
    db.flush()
    db.commit()

    return QRGenerateResponse(
        student_id=student_id,
        qr_token_id=token_id,
        qr_payload=payload_jwt,
        qr_image_base64=qr_service.render_qr_png_base64(payload_jwt),
        issued_at=__import__("datetime").datetime.utcnow(),
    )


@router.post("/{student_id}/revoke-qr")
def revoke_qr(student_id: str, body: QRRevokeRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    s = _get_student_or_404(db, student_id)
    if not s.qr_token_id:
        raise AppError(status.HTTP_400_BAD_REQUEST, "NO_ACTIVE_QR", "This student has no active QR code.")

    s.qr_token_id = None
    db.add(QRAuditLog(student_id=student_id, generated_by=admin.id, action=QRAction.revoked, reason=body.reason))
    db.flush()
    db.commit()
    return {"success": True, "message": "QR code revoked."}


# ------------------------------------------------------------ Self-service
@router.get("/{student_id}/attendance")
def student_attendance_history(student_id: str, db: Session = Depends(get_db), user: User = Depends(require_any_authenticated)):
    if user.role.value == "student" and user.student_id != student_id:
        raise AppError(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "You can only view your own attendance.")
    if user.role.value == "parent" and user.parent_of_student_id != student_id:
        raise AppError(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "You can only view your child's attendance.")
    _get_student_or_404(db, student_id)

    records = (
        db.query(Attendance)
        .filter(Attendance.student_id == student_id)
        .order_by(Attendance.date.desc())
        .limit(90)
        .all()
    )
    return [
        {
            "attendance_id": r.attendance_id,
            "date": r.date.isoformat(),
            "in_time": r.in_time.isoformat() if r.in_time else None,
            "out_time": r.out_time.isoformat() if r.out_time else None,
            "status": r.verification_status.value,
        }
        for r in records
    ]
