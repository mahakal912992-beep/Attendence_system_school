from datetime import date
from typing import List, Optional

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.audit import log_admin_edit
from app.database import get_db
from app.dependencies import AppError, require_admin
from app.models import (AcademicCalendarEntry, AdminEditLog, Attendance,
                         EntityType, FlaggedEvent, QRAuditLog, Role,
                         SystemSettings, User)
from app.schemas import (AttendanceCorrection, FlaggedEventOut,
                          ResolveFlagRequest, SettingUpdate, TeacherCreate,
                          TeacherUpdate)
from app.security import hash_password

router = APIRouter(prefix="/admin", tags=["admin"])


# ---------------------------------------------------------------- Flagged --
@router.get("/flagged-events", response_model=List[FlaggedEventOut])
def list_flagged_events(resolved: Optional[bool] = None, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    q = db.query(FlaggedEvent)
    if resolved is not None:
        q = q.filter(FlaggedEvent.resolved == resolved)
    return q.order_by(FlaggedEvent.created_at.desc()).limit(500).all()


@router.put("/flagged-events/{event_id}/resolve")
def resolve_flagged_event(event_id: str, body: ResolveFlagRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    event = db.query(FlaggedEvent).filter(FlaggedEvent.event_id == event_id).first()
    if not event:
        raise AppError(status.HTTP_404_NOT_FOUND, "EVENT_NOT_FOUND", "Flagged event not found.")
    event.resolved = True
    event.resolved_by = admin.id
    db.flush()
    log_admin_edit(db, admin.id, EntityType.attendance, event_id, {"resolved": False}, {"resolved": True}, body.reason)
    db.commit()
    return {"success": True}


# ---------------------------------------------------------------- Teachers -
@router.post("/teachers", status_code=status.HTTP_201_CREATED)
def create_teacher(body: TeacherCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    if db.query(User).filter(User.email == body.email).first():
        raise AppError(status.HTTP_409_CONFLICT, "EMAIL_TAKEN", "An account with that email already exists.")
    teacher = User(email=body.email, hashed_password=hash_password(body.password), role=Role.teacher, full_name=body.full_name)
    db.add(teacher)
    db.flush()
    log_admin_edit(db, admin.id, EntityType.teacher, teacher.id, None, {"email": body.email, "full_name": body.full_name}, "Teacher account created")
    db.commit()
    return {"success": True, "user_id": teacher.id}


@router.get("/teachers")
def list_teachers(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    teachers = db.query(User).filter(User.role == Role.teacher).all()
    return [{"id": t.id, "email": t.email, "full_name": t.full_name, "is_active": t.is_active} for t in teachers]


@router.patch("/teachers/{teacher_id}")
def update_teacher(teacher_id: str, body: TeacherUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    teacher = db.query(User).filter(User.id == teacher_id, User.role == Role.teacher).first()
    if not teacher:
        raise AppError(status.HTTP_404_NOT_FOUND, "TEACHER_NOT_FOUND", "Teacher not found.")
    old_value = {"full_name": teacher.full_name, "is_active": teacher.is_active}
    if body.full_name is not None:
        teacher.full_name = body.full_name
    if body.is_active is not None:
        teacher.is_active = body.is_active
    db.flush()
    log_admin_edit(db, admin.id, EntityType.teacher, teacher_id, old_value, {"full_name": teacher.full_name, "is_active": teacher.is_active}, body.reason)
    db.commit()
    return {"success": True}


# ------------------------------------------------------------- Attendance --
@router.patch("/attendance/{attendance_id}")
def admin_edit_attendance(attendance_id: str, body: AttendanceCorrection, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    """Admin can edit any attendance record directly - still requires a
    reason and writes to admin_edit_log, same discipline as teacher corrections."""
    record = db.query(Attendance).filter(Attendance.attendance_id == attendance_id).first()
    if not record:
        raise AppError(status.HTTP_404_NOT_FOUND, "RECORD_NOT_FOUND", "Attendance record not found.")

    old_value = {"in_time": record.in_time.isoformat() if record.in_time else None, "out_time": record.out_time.isoformat() if record.out_time else None}
    if body.in_time is not None:
        record.in_time = body.in_time
    if body.out_time is not None:
        record.out_time = body.out_time
    from app.models import VerificationStatus

    record.verification_status = VerificationStatus.manual_override
    db.flush()
    new_value = {"in_time": record.in_time.isoformat() if record.in_time else None, "out_time": record.out_time.isoformat() if record.out_time else None}
    log_admin_edit(db, admin.id, EntityType.attendance, attendance_id, old_value, new_value, body.reason)
    db.commit()
    return {"success": True}


# ---------------------------------------------------------------- Settings -
@router.get("/settings")
def get_settings_list(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return {s.key: s.value for s in db.query(SystemSettings).all()}


@router.put("/settings")
def update_setting(body: SettingUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    setting = db.query(SystemSettings).filter(SystemSettings.key == body.key).first()
    old_value = {"value": setting.value} if setting else None
    if setting:
        setting.value = body.value
    else:
        setting = SystemSettings(key=body.key, value=body.value)
        db.add(setting)
    db.flush()
    log_admin_edit(db, admin.id, EntityType.settings, body.key, old_value, {"value": body.value}, body.reason)
    db.commit()
    return {"success": True}


# ------------------------------------------------------------------- Audit -
@router.get("/edit-log")
def get_admin_edit_log(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    logs = db.query(AdminEditLog).order_by(AdminEditLog.timestamp.desc()).limit(500).all()
    return [
        {
            "log_id": l.log_id, "admin_id": l.admin_id, "entity_type": l.entity_type.value,
            "entity_id": l.entity_id, "old_value": l.old_value, "new_value": l.new_value,
            "reason": l.reason, "timestamp": l.timestamp.isoformat(),
        }
        for l in logs
    ]


@router.get("/qr-audit-log")
def get_qr_audit_log(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    logs = db.query(QRAuditLog).order_by(QRAuditLog.timestamp.desc()).limit(500).all()
    return [
        {"log_id": l.log_id, "student_id": l.student_id, "generated_by": l.generated_by, "action": l.action.value, "reason": l.reason, "timestamp": l.timestamp.isoformat()}
        for l in logs
    ]


# ------------------------------------------------------------------ Calendar
@router.post("/calendar")
def add_calendar_entry(entry_date: date, label: str, is_holiday: bool = True, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    existing = db.query(AcademicCalendarEntry).filter(AcademicCalendarEntry.date == entry_date).first()
    if existing:
        raise AppError(status.HTTP_409_CONFLICT, "DATE_EXISTS", "A calendar entry already exists for that date.")
    entry = AcademicCalendarEntry(date=entry_date, label=label, is_holiday=is_holiday)
    db.add(entry)
    db.flush()
    log_admin_edit(db, admin.id, EntityType.settings, entry.id, None, {"date": str(entry_date), "label": label}, "Calendar entry added")
    db.commit()
    return {"success": True}


@router.get("/calendar")
def list_calendar(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    entries = db.query(AcademicCalendarEntry).order_by(AcademicCalendarEntry.date).all()
    return [{"date": e.date.isoformat(), "label": e.label, "is_holiday": e.is_holiday} for e in entries]
