import logging
from datetime import date, datetime, time

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.crypto import decrypt_vector
from app.database import get_db
from app.dependencies import AppError, require_any_authenticated
from app.rate_limit import limiter
from app.models import (Attendance, FlaggedEventType, Student, SystemSettings,
                         VerificationStatus)
from app.schemas import ScanRequest, ScanResponse
from app.services import fraud_service, notification_service, qr_service
from app.services.face_service import verify_face

logger = logging.getLogger("attendance.scan")
settings = get_settings()

router = APIRouter(prefix="/scan", tags=["scan"])

# IN/OUT cutoff: first verified scan before this time = IN, first scan at/after = OUT logic simplified to
# "first scan of day => IN; any subsequent verified scan => OUT" per Section 5 AI Feature 3.


@router.post("/verify", response_model=ScanResponse)
@limiter.limit(settings.scan_rate_limit)
def verify_scan(request: Request, body: ScanRequest, db: Session = Depends(get_db), user=Depends(require_any_authenticated)):
    ip = request.client.host if request.client else "unknown"

    # ---- 1. Verify QR signature/expiry (never trust client-decoded contents) ----
    payload = qr_service.verify_qr_token(body.qr_payload)
    if not payload:
        fraud_service.record_scan_event(db, None, body.device_id, ip, "qr_invalid")
        fraud_service.flag_event(db, None, FlaggedEventType.invalid_qr, {"reason": "signature_or_expiry_failed", "device_id": body.device_id})
        db.commit()
        raise AppError(status.HTTP_400_BAD_REQUEST, "QR_INVALID", "This QR code could not be verified.")

    student_id = payload.get("student_id")
    token_id = payload.get("token_id")

    student = db.query(Student).filter(Student.student_id == student_id).first()
    if not student or not student.active:
        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "qr_invalid")
        db.commit()
        raise AppError(status.HTTP_400_BAD_REQUEST, "QR_INVALID", "This QR code could not be verified.")

    # ---- 2. Revocation check: token_id must match the student's current active QR ----
    if student.qr_token_id != token_id:
        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "qr_invalid")
        fraud_service.flag_event(db, student_id, FlaggedEventType.invalid_qr, {"reason": "revoked_or_superseded_token"})
        db.commit()
        raise AppError(status.HTTP_400_BAD_REQUEST, "QR_REVOKED", "This QR code is no longer valid.")

    # ---- 3. Consent gate ----
    if not student.biometric_consent:
        raise AppError(status.HTTP_403_FORBIDDEN, "CONSENT_REQUIRED", "Biometric verification is not enabled for this student.")

    # ---- 4. Rate limiting / duplicate-scan protection ----
    if fraud_service.is_duplicate_scan(db, student_id):
        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "rate_limited")
        fraud_service.flag_event(db, student_id, FlaggedEventType.duplicate_scan, {"device_id": body.device_id})
        db.commit()
        raise AppError(status.HTTP_429_TOO_MANY_REQUESTS, "DUPLICATE_SCAN", "A scan was already recorded moments ago.")

    # ---- 5. Location/device anomaly check ----
    anomaly = fraud_service.detect_location_anomaly(db, student_id, body.device_id, body.location)
    if anomaly:
        fraud_service.flag_event(db, student_id, FlaggedEventType.location_anomaly, {"device_id": body.device_id, "location": body.location})
        # Flagged for admin review, but does not block the scan outright - avoids
        # false-positive lockouts from e.g. a lost/replaced device.

    # ---- 6. Server-side face verification (client only ever uploads the image) ----
    stored_embedding = decrypt_vector(student.face_embedding_encrypted) if student.face_embedding_encrypted else None
    threshold_setting = db.query(SystemSettings).filter(SystemSettings.key == "face_match_threshold").first()
    threshold = float(threshold_setting.value) if threshold_setting else None
    result = verify_face(stored_embedding, body.face_image_base64, threshold=threshold)

    if not result["liveness_passed"]:
        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "liveness_failed")
        fraud_service.flag_event(db, student_id, FlaggedEventType.liveness_failed, {"reason": result["reason"]})
        db.commit()
        raise AppError(status.HTTP_401_UNAUTHORIZED, "LIVENESS_FAILED", "Liveness check failed. Please try again with a live camera capture.")

    if not result["matched"]:
        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "face_mismatch")
        fraud_service.flag_event(db, student_id, FlaggedEventType.face_mismatch, {"similarity": result["similarity"], "reason": result["reason"]})
        db.commit()
        raise AppError(status.HTTP_401_UNAUTHORIZED, "FACE_MISMATCH", "Face verification failed.")

    # ---- 7. Transaction-safe IN/OUT determination (race-condition proof) ----
    today = date.today()
    try:
        # SELECT ... FOR UPDATE style row lock (works on Postgres; SQLite
        # falls back to its single-writer lock, sufficient for local/dev).
        existing = (
            db.query(Attendance)
            .filter(Attendance.student_id == student_id, Attendance.date == today)
            .with_for_update(read=False)
            .first()
        )

        now = datetime.utcnow()
        verification_status = VerificationStatus.flagged_fraud if anomaly else VerificationStatus.verified

        if existing is None:
            record = Attendance(
                student_id=student_id,
                date=today,
                in_time=now,
                location=body.location,
                verification_status=verification_status,
                device_id=body.device_id,
            )
            db.add(record)
            out_status = "IN"
        elif existing.out_time is None:
            existing.out_time = now
            existing.device_id = body.device_id
            if anomaly:
                existing.verification_status = VerificationStatus.flagged_fraud
            out_status = "OUT"
        else:
            # Already has both IN and OUT for today - treat as an
            # additional flagged duplicate rather than overwriting history.
            fraud_service.flag_event(db, student_id, FlaggedEventType.duplicate_scan, {"reason": "already_completed_in_out_today"})
            db.commit()
            raise AppError(status.HTTP_409_CONFLICT, "ALREADY_COMPLETE", "Attendance for today is already complete for this student.")

        fraud_service.record_scan_event(db, student_id, body.device_id, ip, "success")
        db.commit()
    except IntegrityError:
        db.rollback()
        raise AppError(status.HTTP_409_CONFLICT, "CONCURRENT_SCAN", "A concurrent scan was already processed. Please try again.")

    # ---- 8. WhatsApp notification (async in spirit; retried + logged, never silently dropped) ----
    try:
        notification_service.send_attendance_notification(db, student, out_status, now)
    except Exception:
        logger.exception("notification_dispatch_error student=%s", student_id)

    return ScanResponse(success=True, status=out_status, time=now, student_name=student.name, message=f"Marked {out_status} at {now.strftime('%I:%M %p')}.")
