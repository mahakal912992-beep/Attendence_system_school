import csv
import io
from datetime import date

from fastapi import APIRouter, Depends, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.audit import log_manual_correction
from app.database import get_db
from app.dependencies import AppError, require_teacher_or_admin
from app.models import Attendance, Student, User, VerificationStatus
from app.schemas import AttendanceCorrection

router = APIRouter(prefix="/teacher", tags=["teacher"])


@router.get("/students/search")
def search_students(q: str = Query(min_length=1), db: Session = Depends(get_db), _: User = Depends(require_teacher_or_admin)):
    like = f"%{q}%"
    students = (
        db.query(Student)
        .filter(or_(Student.name.ilike(like), Student.roll_number.ilike(like), Student.klass.ilike(like)))
        .limit(50)
        .all()
    )
    return [{"student_id": s.student_id, "name": s.name, "class": s.klass, "section": s.section, "roll_number": s.roll_number} for s in students]


@router.patch("/attendance/{attendance_id}")
def correct_attendance(attendance_id: str, body: AttendanceCorrection, db: Session = Depends(get_db), teacher: User = Depends(require_teacher_or_admin)):
    record = db.query(Attendance).filter(Attendance.attendance_id == attendance_id).first()
    if not record:
        raise AppError(status.HTTP_404_NOT_FOUND, "RECORD_NOT_FOUND", "Attendance record not found.")

    old_value = {"in_time": record.in_time.isoformat() if record.in_time else None, "out_time": record.out_time.isoformat() if record.out_time else None}
    if body.in_time is not None:
        record.in_time = body.in_time
    if body.out_time is not None:
        record.out_time = body.out_time
    record.verification_status = VerificationStatus.manual_override
    db.flush()
    new_value = {"in_time": record.in_time.isoformat() if record.in_time else None, "out_time": record.out_time.isoformat() if record.out_time else None}

    log_manual_correction(db, attendance_id, teacher.id, old_value, new_value, body.reason)
    db.commit()
    return {"success": True}


@router.get("/export")
def export_attendance(
    start: date = Query(...),
    end: date = Query(...),
    db: Session = Depends(get_db),
    _: User = Depends(require_teacher_or_admin),
):
    """Exports attendance for the given date range as CSV (opens cleanly in
    Excel). Teachers see all students here since class-level access-scoping
    would be enforced via a class-assignment table in a fuller build; the
    endpoint itself still requires teacher/admin auth."""
    records = (
        db.query(Attendance, Student)
        .join(Student, Attendance.student_id == Student.student_id)
        .filter(Attendance.date >= start, Attendance.date <= end)
        .order_by(Attendance.date, Student.name)
        .all()
    )

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Date", "Student", "Class", "Section", "Roll Number", "In Time", "Out Time", "Status"])
    for att, stu in records:
        writer.writerow([
            att.date.isoformat(), stu.name, stu.klass, stu.section, stu.roll_number,
            att.in_time.strftime("%H:%M:%S") if att.in_time else "",
            att.out_time.strftime("%H:%M:%S") if att.out_time else "",
            att.verification_status.value,
        ])
    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=attendance_{start}_{end}.csv"},
    )
