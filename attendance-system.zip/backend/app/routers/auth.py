import logging
from datetime import datetime

from fastapi import APIRouter, Depends, Request, Response, status
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.rate_limit import limiter
from app.dependencies import AppError, get_current_user, require_admin
from app.models import RefreshToken, Role, User
from app.schemas import LoginRequest, RegisterUserRequest, TokenResponse
from app.security import (create_access_token, generate_refresh_token,
                           hash_password, hash_refresh_token,
                           refresh_token_expiry, verify_password)

logger = logging.getLogger("attendance.auth")
settings = get_settings()

router = APIRouter(prefix="/auth", tags=["auth"])

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 15


@router.post("/login", response_model=TokenResponse)
@limiter.limit(settings.login_rate_limit)
def login(request: Request, response: Response, body: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()

    # Constant-shape error regardless of whether the email exists, to avoid
    # user enumeration.
    generic_error = lambda: AppError(status.HTTP_401_UNAUTHORIZED, "INVALID_CREDENTIALS", "Invalid email or password.")

    if not user:
        raise generic_error()

    if user.locked_until and user.locked_until > datetime.utcnow():
        raise AppError(status.HTTP_423_LOCKED, "ACCOUNT_LOCKED", "Account temporarily locked due to repeated failed logins.")

    if not verify_password(body.password, user.hashed_password):
        user.failed_login_attempts += 1
        if user.failed_login_attempts >= MAX_FAILED_ATTEMPTS:
            from datetime import timedelta

            user.locked_until = datetime.utcnow() + timedelta(minutes=LOCKOUT_MINUTES)
            logger.warning("account_locked user_id=%s", user.id)
        db.commit()
        raise generic_error()

    if not user.is_active:
        raise generic_error()

    user.failed_login_attempts = 0
    user.locked_until = None
    db.commit()

    access_token = create_access_token(user.id, user.role.value)

    raw_refresh = generate_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=hash_refresh_token(raw_refresh), expires_at=refresh_token_expiry()))
    db.commit()

    # Refresh token: httpOnly cookie only, never in the JSON body / localStorage
    response.set_cookie(
        key="refresh_token",
        value=raw_refresh,
        httponly=True,
        secure=settings.is_production,
        samesite="strict",
        max_age=settings.refresh_token_expire_days * 24 * 3600,
        path="/auth",
    )

    return TokenResponse(access_token=access_token, role=user.role.value)


@router.post("/refresh", response_model=TokenResponse)
def refresh(request: Request, db: Session = Depends(get_db)):
    raw_refresh = request.cookies.get("refresh_token")
    if not raw_refresh:
        raise AppError(status.HTTP_401_UNAUTHORIZED, "NO_REFRESH_TOKEN", "Please log in again.")

    token_hash = hash_refresh_token(raw_refresh)
    stored = db.query(RefreshToken).filter(RefreshToken.token_hash == token_hash, RefreshToken.revoked.is_(False)).first()
    if not stored or stored.expires_at < datetime.utcnow():
        raise AppError(status.HTTP_401_UNAUTHORIZED, "INVALID_REFRESH_TOKEN", "Please log in again.")

    user = db.query(User).filter(User.id == stored.user_id).first()
    if not user or not user.is_active:
        raise AppError(status.HTTP_401_UNAUTHORIZED, "INVALID_REFRESH_TOKEN", "Please log in again.")

    access_token = create_access_token(user.id, user.role.value)
    return TokenResponse(access_token=access_token, role=user.role.value)


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    raw_refresh = request.cookies.get("refresh_token")
    if raw_refresh:
        token_hash = hash_refresh_token(raw_refresh)
        stored = db.query(RefreshToken).filter(RefreshToken.token_hash == token_hash).first()
        if stored:
            stored.revoked = True
            db.commit()
    response.delete_cookie("refresh_token", path="/auth")
    return {"success": True, "message": "Logged out."}


@router.post("/register-staff", status_code=status.HTTP_201_CREATED)
def register_staff(body: RegisterUserRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    """Only an admin can create teacher/admin accounts. Student/parent
    accounts are provisioned through /admin/students linkage instead."""
    if body.role not in ("teacher", "admin"):
        raise AppError(status.HTTP_400_BAD_REQUEST, "INVALID_ROLE", "Use the student/parent provisioning flow for that role.")

    if db.query(User).filter(User.email == body.email).first():
        raise AppError(status.HTTP_409_CONFLICT, "EMAIL_TAKEN", "An account with that email already exists.")

    user = User(email=body.email, hashed_password=hash_password(body.password), role=Role(body.role), full_name=body.full_name)
    db.add(user)
    db.commit()
    return {"success": True, "user_id": user.id}


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return {
        "id": user.id,
        "email": user.email,
        "role": user.role.value,
        "full_name": user.full_name,
        "student_id": user.student_id,
        "parent_of_student_id": user.parent_of_student_id,
    }
