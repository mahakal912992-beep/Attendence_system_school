from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.security import decode_access_token

bearer_scheme = HTTPBearer(auto_error=False)


class AppError(HTTPException):
    """Structured error: never leaks internals to the client."""

    def __init__(self, status_code: int, error_code: str, message: str):
        super().__init__(status_code=status_code, detail={"success": False, "error_code": error_code, "message": message})


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if credentials is None:
        raise AppError(status.HTTP_401_UNAUTHORIZED, "NO_TOKEN", "Authentication required.")

    payload = decode_access_token(credentials.credentials)
    if not payload:
        raise AppError(status.HTTP_401_UNAUTHORIZED, "INVALID_TOKEN", "Session expired or invalid. Please log in again.")

    # CRITICAL: always re-fetch the user + role from the DB. Never trust the
    # role claim in the token alone for authorization decisions on
    # sensitive actions - the DB is the source of truth in case a role
    # changed or the account was deactivated after the token was issued.
    user = db.query(User).filter(User.id == payload["sub"]).first()
    if not user or not user.is_active:
        raise AppError(status.HTTP_401_UNAUTHORIZED, "INVALID_TOKEN", "Session expired or invalid. Please log in again.")

    return user


def require_roles(*allowed_roles: str):
    def _dependency(user: User = Depends(get_current_user)) -> User:
        if user.role.value not in allowed_roles:
            raise AppError(
                status.HTTP_403_FORBIDDEN,
                "FORBIDDEN",
                "You do not have permission to perform this action.",
            )
        return user

    return _dependency


require_admin = require_roles("admin")
require_teacher_or_admin = require_roles("teacher", "admin")
require_any_authenticated = require_roles("student", "parent", "teacher", "admin")
