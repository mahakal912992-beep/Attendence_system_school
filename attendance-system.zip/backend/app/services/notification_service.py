"""
WhatsApp is the sole external notification channel (Section 7/10). This
module sends the IN/OUT templates from Section 3, retries transient
failures with backoff, and always logs the outcome to notifications_log -
failures are never silently dropped.

WHATSAPP_PROVIDER=mock  -> logs the message and simulates occasional
                            transient failure so the retry path is exercised.
WHATSAPP_PROVIDER=twilio / meta_cloud_api -> real HTTP calls using the
                            credentials in .env (never hardcoded).
"""
import logging
import random
import time
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from app.config import get_settings
from app.crypto import decrypt_text, mask_phone
from app.models import NotificationLog, NotificationStatus, Student

logger = logging.getLogger("attendance.notifications")
settings = get_settings()

MAX_RETRIES = 3
BACKOFF_BASE_SECONDS = 0.4  # kept short so the demo UI feels responsive


def _render_template(student_name: str, klass: str, section: str, status: str, when: datetime) -> str:
    label = "entered" if status == "IN" else "left"
    return (
        f"ABC Public School\n"
        f"Student: {student_name}\n"
        f"Class: {klass}-{section}\n"
        f"Time: {when.strftime('%I:%M %p')}\n"
        f"Status: {status}\n"
        f"Your child has {label} the school campus."
    )


def _send_via_provider(phone: str, message: str) -> bool:
    """Returns True on success. Real providers raise/timeout on failure;
    here we simulate an occasional transient failure for the mock path so
    the retry-with-backoff logic is genuinely exercised."""
    if settings.whatsapp_provider == "mock":
        # ~15% simulated transient failure rate to demonstrate retry path
        return random.random() > 0.15

    if settings.whatsapp_provider in ("twilio", "meta_cloud_api"):
        # Real integration point - intentionally not implemented with fake
        # network calls here. Wire this up to the Twilio/Meta SDK using the
        # credentials from app.config.get_settings() when going live.
        raise NotImplementedError(f"WhatsApp provider '{settings.whatsapp_provider}' not wired to a live API yet.")

    raise ValueError(f"Unknown WHATSAPP_PROVIDER '{settings.whatsapp_provider}'")


def send_attendance_notification(db: Session, student: Student, status: str, when: datetime) -> NotificationLog:
    phone = decrypt_text(student.parent_phone_encrypted)
    message = _render_template(student.name, student.klass, student.section, status, when)

    log = NotificationLog(student_id=student.student_id, status=NotificationStatus.pending, attempt_count=0)
    db.add(log)
    db.flush()

    last_error: Optional[str] = None
    for attempt in range(1, MAX_RETRIES + 1):
        log.attempt_count = attempt
        try:
            ok = _send_via_provider(phone, message)
            if ok:
                log.status = NotificationStatus.sent
                log.sent_at = datetime.utcnow()
                db.commit()
                logger.info("whatsapp_sent student=%s phone=%s attempt=%d", student.student_id, mask_phone(phone), attempt)
                return log
            last_error = "provider_returned_failure"
        except Exception as exc:  # never let a notification failure break the scan flow
            last_error = str(exc)[:200]
            logger.warning("whatsapp_attempt_failed student=%s attempt=%d error=%s", student.student_id, attempt, last_error)

        if attempt < MAX_RETRIES:
            time.sleep(BACKOFF_BASE_SECONDS * attempt)

    log.status = NotificationStatus.failed
    log.last_error = last_error
    db.commit()
    logger.error("whatsapp_failed_all_retries student=%s phone=%s", student.student_id, mask_phone(phone))
    return log
