"""
Fraud & abuse prevention (Section 0.6 / AI Feature 2):
- rate-limits scan attempts per student per minute
- logs device_id/IP with every scan
- flags impossible-travel-style anomalies (same student "in" at two
  locations within a window too short to be physically possible)
Every flagged condition here is written to flagged_events - never
silently auto-approved.
"""
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from app.models import FlaggedEvent, FlaggedEventType, ScanEvent

SCAN_COOLDOWN_SECONDS = 20          # min gap between successful scans for the same student
IMPOSSIBLE_TRAVEL_WINDOW_SECONDS = 120  # a location change faster than this is suspicious


def is_duplicate_scan(db: Session, student_id: str) -> bool:
    cutoff = datetime.utcnow() - timedelta(seconds=SCAN_COOLDOWN_SECONDS)
    recent = (
        db.query(ScanEvent)
        .filter(ScanEvent.student_id == student_id, ScanEvent.outcome == "success", ScanEvent.created_at >= cutoff)
        .first()
    )
    return recent is not None


def detect_location_anomaly(db: Session, student_id: str, device_id: str, location: Optional[str]) -> bool:
    if not location:
        return False
    cutoff = datetime.utcnow() - timedelta(seconds=IMPOSSIBLE_TRAVEL_WINDOW_SECONDS)
    recent = (
        db.query(ScanEvent)
        .filter(ScanEvent.student_id == student_id, ScanEvent.outcome == "success", ScanEvent.created_at >= cutoff)
        .order_by(ScanEvent.created_at.desc())
        .first()
    )
    if recent and recent.device_id and recent.device_id != device_id:
        return True
    return False


def record_scan_event(db: Session, student_id: Optional[str], device_id: str, ip_address: str, outcome: str) -> ScanEvent:
    event = ScanEvent(student_id=student_id, device_id=device_id, ip_address=ip_address, outcome=outcome)
    db.add(event)
    db.flush()
    return event


def flag_event(db: Session, student_id: Optional[str], event_type: FlaggedEventType, details: dict) -> FlaggedEvent:
    flag = FlaggedEvent(student_id=student_id, event_type=event_type, details=details)
    db.add(flag)
    db.flush()
    return flag
