"""
QR payload = a signed JWT (separate secret from the auth JWT) containing
student_id, a unique token_id, and issued_at. The token_id is what we store
on the student row (`qr_token_id`) and check for revocation - never the
raw payload, and never a plain/guessable student id on its own.
"""
import base64
import io
import uuid
from datetime import datetime, timedelta
from typing import Optional

import qrcode
from jose import JWTError, jwt

from app.config import get_settings

settings = get_settings()

QR_ALGORITHM = "HS256"
QR_TOKEN_VALIDITY_DAYS = 400  # ~ annual rotation per Section 6 recommendation


def issue_qr_token(student_id: str) -> tuple[str, str]:
    """Returns (payload_jwt, token_id)."""
    token_id = str(uuid.uuid4())
    issued_at = datetime.utcnow()
    expires_at = issued_at + timedelta(days=QR_TOKEN_VALIDITY_DAYS)
    payload = {
        "student_id": student_id,
        "token_id": token_id,
        "iat": issued_at,
        "exp": expires_at,
    }
    signed = jwt.encode(payload, settings.qr_signing_secret, algorithm=QR_ALGORITHM)
    return signed, token_id


def verify_qr_token(payload_jwt: str) -> Optional[dict]:
    """Verifies signature + expiry only. Caller must separately check
    revocation status (token_id matches student's current active qr_token_id)."""
    try:
        return jwt.decode(payload_jwt, settings.qr_signing_secret, algorithms=[QR_ALGORITHM])
    except JWTError:
        return None


def render_qr_png_base64(payload_jwt: str) -> str:
    img = qrcode.make(payload_jwt)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()
