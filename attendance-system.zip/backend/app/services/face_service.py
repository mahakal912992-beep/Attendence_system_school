"""
Face verification service.

Architecture note: the client (mobile/web app) NEVER computes or reports a
match result. It only uploads an image. This module is the single place
that (a) validates the upload is really an image, (b) generates an
embedding, (c) compares it to the stored embedding, and (d) makes the
threshold decision - entirely server-side.

FACE_PROVIDER=mock   -> deterministic pseudo-embedding + simple heuristics,
                         good enough to demo the full IN/OUT flow without a
                         GPU or paid API.
FACE_PROVIDER=insightface -> swap in a real self-hosted model here; the
                         function signatures below are the integration
                         contract the rest of the app relies on.
"""
import base64
import binascii
import hashlib
import io
import math
from dataclasses import dataclass
from typing import List, Optional

from PIL import Image, UnidentifiedImageError

from app.config import get_settings

settings = get_settings()

MAX_IMAGE_BYTES = 6 * 1024 * 1024  # 6MB upload cap
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


class ImageValidationError(Exception):
    pass


@dataclass
class DecodedImage:
    image: Image.Image
    raw_bytes: bytes


def decode_and_validate_image(face_image_base64: str) -> DecodedImage:
    """Verifies the upload is actually a real, decodable image of an
    allowed type (content inspection, not trusting a filename/extension),
    and enforces the size cap. Also strips EXIF metadata."""
    try:
        raw = base64.b64decode(face_image_base64, validate=True)
    except (binascii.Error, ValueError):
        raise ImageValidationError("Uploaded data is not valid base64 image content.")

    if len(raw) > MAX_IMAGE_BYTES:
        raise ImageValidationError("Image exceeds maximum allowed size.")

    try:
        img = Image.open(io.BytesIO(raw))
        img.verify()  # checks integrity
        img = Image.open(io.BytesIO(raw))  # re-open, verify() consumes the parser
    except UnidentifiedImageError:
        raise ImageValidationError("Uploaded data is not a recognizable image.")

    if img.format not in ALLOWED_FORMATS:
        raise ImageValidationError("Unsupported image format.")

    # Strip EXIF / metadata before we ever persist or process further
    clean = Image.new(img.mode, img.size)
    clean.putdata(list(img.getdata()))

    out_buf = io.BytesIO()
    clean.save(out_buf, format="PNG")
    return DecodedImage(image=clean, raw_bytes=out_buf.getvalue())


def generate_embedding(decoded: DecodedImage) -> List[float]:
    """MOCK implementation: derives a stable pseudo-embedding from image
    content so that the *same* photo always yields the *same* vector and
    different photos yield different ones - enough to demonstrate the
    end-to-end match/no-match/threshold flow deterministically.

    Swap this out for a real InsightFace/FaceNet inference call in
    production; keep the return type (list[float], L2-normalizable)."""
    # Multiple hash rounds -> a longer, better-distributed vector than a
    # single 32-byte digest. Centered to [-1, 1] (not [0, 1]) so unrelated
    # images don't share a systematic positive-correlation bias - without
    # this, cosine similarity between *any* two unrelated mock embeddings
    # averaged ~0.75, i.e. right at the match threshold, making the
    # threshold meaningless. Centering brings unrelated pairs to ~0.
    raw = []
    for round_i in range(4):
        raw.extend(hashlib.sha256(decoded.raw_bytes + bytes([round_i])).digest())
    vector = [(b / 127.5) - 1.0 for b in raw]
    norm = math.sqrt(sum(v * v for v in vector)) or 1.0
    return [v / norm for v in vector]


def cosine_similarity(a: List[float], b: List[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return dot / (na * nb)


def check_liveness(decoded: DecodedImage) -> bool:
    """MOCK liveness/anti-spoof heuristic: rejects near-blank or
    near-uniform images (a common signature of a photo-of-a-screen replay
    with washed out contrast, or a corrupted capture). Real deployments
    should replace this with an active liveness SDK (blink/movement/depth).
    """
    grayscale = decoded.image.convert("L")
    histogram = grayscale.histogram()
    total_pixels = sum(histogram)
    if total_pixels == 0:
        return False
    # Shannon entropy of the pixel intensity distribution
    entropy = -sum((c / total_pixels) * math.log2(c / total_pixels) for c in histogram if c > 0)
    return entropy > 3.0  # very flat/blank images score near 0


def verify_face(stored_embedding: Optional[List[float]], face_image_base64: str, threshold: Optional[float] = None) -> dict:
    """Returns a structured, server-decided result:
    {matched: bool, similarity: float, liveness_passed: bool, reason: str|None}
    Never trusts anything the client claims about the match."""
    match_threshold = threshold if threshold is not None else settings.face_match_threshold
    if not stored_embedding:
        return {"matched": False, "similarity": 0.0, "liveness_passed": False, "reason": "no_registered_photo"}

    try:
        decoded = decode_and_validate_image(face_image_base64)
    except ImageValidationError as e:
        return {"matched": False, "similarity": 0.0, "liveness_passed": False, "reason": str(e)}

    liveness_ok = check_liveness(decoded)
    if not liveness_ok:
        return {"matched": False, "similarity": 0.0, "liveness_passed": False, "reason": "liveness_check_failed"}

    candidate_embedding = generate_embedding(decoded)
    similarity = cosine_similarity(stored_embedding, candidate_embedding)
    matched = similarity >= match_threshold

    return {
        "matched": matched,
        "similarity": round(similarity, 4),
        "liveness_passed": True,
        "reason": None if matched else "similarity_below_threshold",
    }
