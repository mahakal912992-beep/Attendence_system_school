"""
Seeds a small demo dataset so the reviewer can log in and see the whole
system working immediately: 1 admin, 1 teacher, 2 students each with a
parent account, sample attendance history, and a couple of flagged events.

Run with:  python -m app.seed
"""
import base64
import io
import random
from datetime import date, datetime, timedelta

from PIL import Image

from app.crypto import encrypt_text, encrypt_vector
from app.database import Base, SessionLocal, engine
from app.models import (Attendance, FlaggedEvent, FlaggedEventType, QRAction,
                         QRAuditLog, Role, Student, SystemSettings, User,
                         VerificationStatus)
from app.security import hash_password
from app.services import face_service, qr_service

DEMO_PASSWORD = "DemoPass123!"


def _fake_photo_bytes(seed: int) -> bytes:
    """Deterministic synthetic 'photo' per student so registered-photo vs
    live-capture matching is demonstrable without real face images."""
    random.seed(seed)
    img = Image.new("RGB", (120, 120))
    pixels = [
        (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        for _ in range(120 * 120)
    ]
    img.putdata(pixels)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == "admin@school.demo").first():
            print("Already seeded.")
            return

        admin = User(email="admin@school.demo", hashed_password=hash_password(DEMO_PASSWORD), role=Role.admin, full_name="Priya Sharma (Admin)")
        teacher = User(email="teacher@school.demo", hashed_password=hash_password(DEMO_PASSWORD), role=Role.teacher, full_name="Ravi Verma (Teacher)")
        db.add_all([admin, teacher])
        db.flush()

        students_data = [
            {"name": "Rahul Kumar", "klass": "10", "section": "A", "roll_number": "21", "parent_name": "Sunita Kumar", "parent_phone": "+919876543210"},
            {"name": "Ananya Singh", "klass": "8", "section": "B", "roll_number": "07", "parent_name": "Vikram Singh", "parent_phone": "+919812345678"},
        ]

        for i, sd in enumerate(students_data):
            student = Student(
                name=sd["name"], klass=sd["klass"], section=sd["section"], roll_number=sd["roll_number"],
                parent_name=sd["parent_name"], parent_phone_encrypted=encrypt_text(sd["parent_phone"]),
                biometric_consent=True,
            )
            db.add(student)
            db.flush()

            photo_bytes = _fake_photo_bytes(seed=i + 1)
            b64 = base64.b64encode(photo_bytes).decode()
            decoded = face_service.decode_and_validate_image(b64)
            embedding = face_service.generate_embedding(decoded)
            student.face_embedding_encrypted = encrypt_vector(embedding)
            student.photo_url = None  # demo photo intentionally not persisted to disk

            payload_jwt, token_id = qr_service.issue_qr_token(student.student_id)
            student.qr_token_id = token_id
            db.add(QRAuditLog(student_id=student.student_id, generated_by=admin.id, action=QRAction.generated, reason="Initial issuance (seed data)"))

            parent_user = User(
                email=f"parent{i+1}@school.demo", hashed_password=hash_password(DEMO_PASSWORD), role=Role.parent,
                full_name=f"{sd['parent_name']} (Parent)", parent_of_student_id=student.student_id,
            )
            student_user = User(
                email=f"student{i+1}@school.demo", hashed_password=hash_password(DEMO_PASSWORD), role=Role.student,
                full_name=sd["name"], student_id=student.student_id,
            )
            db.add_all([parent_user, student_user])

            # A few days of attendance history
            for d in range(5, 0, -1):
                day = date.today() - timedelta(days=d)
                in_t = datetime.combine(day, datetime.min.time()) + timedelta(hours=8, minutes=random.randint(0, 40))
                out_t = in_t + timedelta(hours=6, minutes=random.randint(0, 30))
                db.add(Attendance(student_id=student.student_id, date=day, in_time=in_t, out_time=out_t, verification_status=VerificationStatus.verified, device_id="seed-device"))

            if i == 0:
                db.add(FlaggedEvent(student_id=student.student_id, event_type=FlaggedEventType.duplicate_scan, details={"note": "Sample flagged event for demo"}, resolved=False))

            print(f"Seeded student '{sd['name']}' | QR payload (for manual testing):\n{payload_jwt}\n")

        db.add(SystemSettings(key="in_out_cutoff_time", value="09:00"))
        db.add(SystemSettings(key="face_match_threshold", value="0.75"))

        db.commit()
        print("Seed complete.")
        print(f"Demo password for all accounts: {DEMO_PASSWORD}")
        print("Logins: admin@school.demo, teacher@school.demo, parent1@school.demo, student1@school.demo, parent2@school.demo, student2@school.demo")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
