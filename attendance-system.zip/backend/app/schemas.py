from datetime import date, datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---------------------------------------------------------------- Common ---
class ErrorResponse(BaseModel):
    success: bool = False
    error_code: str
    message: str


# ------------------------------------------------------------------ Auth ---
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str


class RegisterUserRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str
    role: str  # validated against allowed roles server-side
    student_id: Optional[str] = None            # for role=student
    parent_of_student_id: Optional[str] = None   # for role=parent

    @field_validator("role")
    @classmethod
    def role_must_be_valid(cls, v):
        allowed = {"student", "parent", "teacher", "admin"}
        if v not in allowed:
            raise ValueError("invalid role")
        return v


# --------------------------------------------------------------- Student ---
PHONE_REGEX = r"^\+?[1-9]\d{7,14}$"


class StudentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    klass: str = Field(min_length=1, max_length=20, alias="class")
    section: str = Field(min_length=1, max_length=10)
    roll_number: str = Field(min_length=1, max_length=20)
    parent_name: str = Field(min_length=1, max_length=120)
    parent_phone: str = Field(pattern=PHONE_REGEX)

    model_config = {"populate_by_name": True}


class StudentUpdate(BaseModel):
    name: Optional[str] = None
    klass: Optional[str] = Field(default=None, alias="class")
    section: Optional[str] = None
    roll_number: Optional[str] = None
    parent_name: Optional[str] = None
    parent_phone: Optional[str] = Field(default=None, pattern=PHONE_REGEX)
    active: Optional[bool] = None
    reason: str = Field(min_length=3, description="Required: why this edit is being made")

    model_config = {"populate_by_name": True}


class StudentOut(BaseModel):
    student_id: str
    name: str
    klass: str = Field(serialization_alias="class")
    section: str
    roll_number: str
    parent_name: str
    parent_phone_masked: str
    photo_url: Optional[str]
    biometric_consent: bool
    active: bool
    has_active_qr: bool

    model_config = {"populate_by_name": True}


class ConsentUpdate(BaseModel):
    consent: bool
    reason: str = Field(min_length=3)


# ------------------------------------------------------------------- QR ----
class QRGenerateRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=200)


class QRGenerateResponse(BaseModel):
    student_id: str
    qr_token_id: str
    qr_payload: str
    qr_image_base64: str
    issued_at: datetime


class QRRevokeRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=200)


# ------------------------------------------------------------------ Scan ---
class ScanRequest(BaseModel):
    qr_payload: str
    device_id: str = Field(min_length=1, max_length=100)
    location: Optional[str] = None
    face_image_base64: str = Field(min_length=10)


class ScanResponse(BaseModel):
    success: bool
    status: Optional[str] = None  # IN | OUT
    time: Optional[datetime] = None
    student_name: Optional[str] = None
    message: str


# ------------------------------------------------------------ Attendance ---
class AttendanceOut(BaseModel):
    attendance_id: str
    student_id: str
    date: date
    in_time: Optional[datetime]
    out_time: Optional[datetime]
    location: Optional[str]
    verification_status: str
    device_id: Optional[str]


class AttendanceCorrection(BaseModel):
    in_time: Optional[datetime] = None
    out_time: Optional[datetime] = None
    reason: str = Field(min_length=3)


# ------------------------------------------------------------- Flag / Log --
class FlaggedEventOut(BaseModel):
    event_id: str
    student_id: Optional[str]
    event_type: str
    details: Optional[Dict[str, Any]]
    resolved: bool
    created_at: datetime


class ResolveFlagRequest(BaseModel):
    reason: str = Field(min_length=3)


# -------------------------------------------------------------- Settings ---
class SettingUpdate(BaseModel):
    key: str
    value: str
    reason: str = Field(min_length=3)


# ---------------------------------------------------------------- Teacher --
class TeacherCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str


class TeacherUpdate(BaseModel):
    full_name: Optional[str] = None
    is_active: Optional[bool] = None
    reason: str = Field(min_length=3)


# -------------------------------------------------------------- Analytics --
class AnalyticsSummary(BaseModel):
    total_students: int
    present_today: int
    absent_today: int
    late_arrivals_today: int
    attendance_rate_30d: float
    open_flagged_events: int
