"""
Field-level encryption for sensitive columns (face embeddings, parent phone
numbers) using Fernet (AES-128-CBC + HMAC). The key lives only in the
environment (FIELD_ENCRYPTION_KEY) - never in source.
"""
import base64
import json
from typing import List

from cryptography.fernet import Fernet

from app.config import get_settings

settings = get_settings()
_fernet = Fernet(settings.field_encryption_key.encode())


def encrypt_text(plaintext: str) -> str:
    if plaintext is None:
        return None
    return _fernet.encrypt(plaintext.encode()).decode()


def decrypt_text(ciphertext: str) -> str:
    if ciphertext is None:
        return None
    return _fernet.decrypt(ciphertext.encode()).decode()


def encrypt_vector(vector: List[float]) -> str:
    """Encrypt a face embedding (list of floats) for storage."""
    raw = json.dumps(vector).encode()
    return base64.urlsafe_b64encode(_fernet.encrypt(raw)).decode()


def decrypt_vector(ciphertext: str) -> List[float]:
    raw = _fernet.decrypt(base64.urlsafe_b64decode(ciphertext.encode()))
    return json.loads(raw.decode())


def mask_phone(phone: str) -> str:
    """e.g. +919876543210 -> +91XXXXX3210  (used in logs / non-admin responses)"""
    if not phone or len(phone) < 4:
        return "***"
    return phone[:3] + "X" * max(len(phone) - 7, 4) + phone[-4:]
