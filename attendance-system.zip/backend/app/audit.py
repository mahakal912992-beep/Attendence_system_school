from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from app.models import AdminEditLog, EntityType, ManualCorrectionLog


def log_admin_edit(
    db: Session,
    admin_id: str,
    entity_type: EntityType,
    entity_id: str,
    old_value: Optional[Dict[str, Any]],
    new_value: Optional[Dict[str, Any]],
    reason: str,
) -> None:
    """'Admin can edit everything' is a permission, not an exemption from
    logging - every admin write goes through this, no exceptions."""
    db.add(
        AdminEditLog(
            admin_id=admin_id,
            entity_type=entity_type,
            entity_id=entity_id,
            old_value=old_value,
            new_value=new_value,
            reason=reason,
        )
    )
    db.flush()


def log_manual_correction(
    db: Session,
    attendance_id: str,
    corrected_by: str,
    old_value: Dict[str, Any],
    new_value: Dict[str, Any],
    reason: str,
) -> None:
    db.add(
        ManualCorrectionLog(
            attendance_id=attendance_id,
            corrected_by=corrected_by,
            old_value=old_value,
            new_value=new_value,
            reason=reason,
        )
    )
    db.flush()
