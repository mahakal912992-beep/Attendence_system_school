import base64
import io
import json
import random
import urllib.error
import urllib.request

BASE = "http://localhost:8000"


def call(method, path, token=None, body=None, expect=None, label=""):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            status = resp.status
            payload = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        status = e.code
        try:
            payload = json.loads(e.read().decode())
        except Exception:
            payload = {}
    mark = "OK" if (expect is None or status == expect) else "FAIL"
    print(f"[{mark}] {label or path} -> {status}")
    return status, payload


def fake_face_b64(seed):
    random.seed(seed)
    img_bytes_gen = __import__("PIL.Image", fromlist=["Image"])
    img = img_bytes_gen.new("RGB", (120, 120))
    img.putdata([(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for _ in range(120 * 120)])
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


print("=== Health ===")
call("GET", "/health", expect=200)

print("\n=== Auth ===")
_, body = call("POST", "/auth/login", body={"email": "admin@school.demo", "password": "DemoPass123!"}, expect=200, label="admin login")
admin_token = body["access_token"]

_, body = call("POST", "/auth/login", body={"email": "student1@school.demo", "password": "DemoPass123!"}, expect=200, label="student login")
student_token = body["access_token"]

status, _ = call("POST", "/auth/login", body={"email": "admin@school.demo", "password": "WRONG"}, expect=401, label="wrong password")

print("\n=== RBAC ===")
_, students = call("GET", "/students", token=admin_token, expect=200, label="admin list students")
rahul = next(s for s in students if s["name"] == "Rahul Kumar")
student_id = rahul["student_id"]

call("POST", f"/students/{student_id}/generate-qr", token=student_token, body={"reason": "x"}, expect=403, label="student tries generate-qr (should be forbidden)")
_, qr_resp = call("POST", f"/students/{student_id}/generate-qr", token=admin_token, body={"reason": "fresh qr for smoke test"}, expect=200, label="admin generate-qr")
qr_payload = qr_resp["qr_payload"]

print("\n=== Scan flow ===")
face_b64 = fake_face_b64(seed=1)  # matches the seed script's registered photo for student[0] (seeded with i=0 -> seed=1)
status, resp = call(
    "POST", "/scan/verify", token=student_token,
    body={"qr_payload": qr_payload, "device_id": "kiosk-01", "location": "main-gate", "face_image_base64": face_b64},
    expect=200, label="scan 1 (expect IN)",
)
print("   ->", resp)

status, resp = call(
    "POST", "/scan/verify", token=student_token,
    body={"qr_payload": qr_payload, "device_id": "kiosk-01", "location": "main-gate", "face_image_base64": face_b64},
    expect=429, label="scan 2 immediately after (expect duplicate/rate-limited)",
)
print("   ->", resp)

wrong_face_b64 = fake_face_b64(seed=999)
status, resp = call(
    "POST", "/scan/verify", token=student_token,
    body={"qr_payload": qr_payload, "device_id": "kiosk-02", "location": "main-gate", "face_image_base64": wrong_face_b64},
    label="scan with wrong face (expect 401 mismatch or liveness fail)",
)
print("   ->", status, resp)

print("\n=== QR revocation ===")
call("POST", f"/students/{student_id}/revoke-qr", token=admin_token, body={"reason": "smoke test revoke"}, expect=200, label="admin revoke qr")
status, resp = call(
    "POST", "/scan/verify", token=student_token,
    body={"qr_payload": qr_payload, "device_id": "kiosk-03", "location": "main-gate", "face_image_base64": face_b64},
    expect=400, label="scan with revoked qr (expect 400)",
)
print("   ->", resp)

print("\n=== Analytics & flagged events ===")
call("GET", "/analytics/summary", token=admin_token, expect=200, label="admin analytics summary")
call("GET", "/admin/flagged-events", token=admin_token, expect=200, label="admin list flagged events")

print("\n=== Teacher export ===")
req = urllib.request.Request(f"{BASE}/teacher/export?start=2020-01-01&end=2030-01-01", method="GET")
teacher_token = call("POST", "/auth/login", body={"email": "teacher@school.demo", "password": "DemoPass123!"}, expect=200, label="teacher login")[1]["access_token"]
req.add_header("Authorization", f"Bearer {teacher_token}")
with urllib.request.urlopen(req, timeout=10) as resp:
    print("[OK] teacher export ->", resp.status, "bytes:", len(resp.read()))

print("\nALL SMOKE TESTS EXECUTED")
