import os
import sys

os.environ.setdefault("DATABASE_URL", "sqlite:///./test_attendance.db")
os.environ.setdefault("JWT_SECRET_KEY", "test-jwt-secret-key-not-for-production")
os.environ.setdefault("QR_SIGNING_SECRET", "test-qr-secret-key-not-for-production")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import base64
import io
from datetime import datetime

import pytest
from cryptography.fernet import Fernet
from fastapi.testclient import TestClient
from PIL import Image

os.environ.setdefault("FIELD_ENCRYPTION_KEY", Fernet.generate_key().decode())

from app.config import get_settings
from app.database import Base, SessionLocal, engine
from app.main import app
from app.models import Role, Student, User
from app.security import hash_password
from app.services import face_service, qr_service
from app.crypto import encrypt_text, encrypt_vector

get_settings.cache_clear()


@pytest.fixture(scope="function", autouse=True)
def fresh_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    app.state.limiter.reset()
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(app)


def make_face_b64(seed: int) -> str:
    import random

    random.seed(seed)
    img = Image.new("RGB", (100, 100))
    img.putdata([(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for _ in range(100 * 100)])
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


@pytest.fixture
def seeded_data():
    db = SessionLocal()
    try:
        admin = User(email="admin@testmail.example", hashed_password=hash_password("AdminPass123!"), role=Role.admin, full_name="Test Admin")
        db.add(admin)
        db.flush()

        student = Student(
            name="Test Student", klass="9", section="A", roll_number="1",
            parent_name="Test Parent", parent_phone_encrypted=encrypt_text("+919999999999"),
            biometric_consent=True,
        )
        db.add(student)
        db.flush()

        face_b64 = make_face_b64(seed=1)
        decoded = face_service.decode_and_validate_image(face_b64)
        embedding = face_service.generate_embedding(decoded)
        student.face_embedding_encrypted = encrypt_vector(embedding)

        payload_jwt, token_id = qr_service.issue_qr_token(student.student_id)
        student.qr_token_id = token_id

        student_user = User(email="student@testmail.example", hashed_password=hash_password("StudentPass123!"), role=Role.student, full_name="Test Student", student_id=student.student_id)
        db.add(student_user)

        db.commit()
        return {
            "student_id": student.student_id,
            "qr_payload": payload_jwt,
            "face_b64": face_b64,
        }
    finally:
        db.close()
