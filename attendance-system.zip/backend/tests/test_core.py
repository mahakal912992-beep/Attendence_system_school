from tests.conftest import make_face_b64


def login(client, email, password):
    r = client.post("/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


class TestAuth:
    def test_login_success(self, client, seeded_data):
        r = client.post("/auth/login", json={"email": "admin@testmail.example", "password": "AdminPass123!"})
        assert r.status_code == 200
        assert "access_token" in r.json()

    def test_login_wrong_password(self, client, seeded_data):
        r = client.post("/auth/login", json={"email": "admin@testmail.example", "password": "wrong"})
        assert r.status_code == 401
        assert r.json()["error_code"] == "INVALID_CREDENTIALS"

    def test_login_unknown_email_same_error_shape(self, client, seeded_data):
        r = client.post("/auth/login", json={"email": "nope@testmail.example", "password": "whatever"})
        assert r.status_code == 401
        assert r.json()["error_code"] == "INVALID_CREDENTIALS"

    def test_account_lockout_after_repeated_failures(self, client, seeded_data):
        for _ in range(5):
            client.post("/auth/login", json={"email": "admin@testmail.example", "password": "wrong"})
        r = client.post("/auth/login", json={"email": "admin@testmail.example", "password": "AdminPass123!"})
        assert r.status_code == 423

    def test_protected_endpoint_requires_token(self, client, seeded_data):
        r = client.get("/students")
        assert r.status_code == 401

    def test_invalid_token_rejected(self, client, seeded_data):
        r = client.get("/students", headers={"Authorization": "Bearer garbage.token.value"})
        assert r.status_code == 401


class TestRBAC:
    def test_student_cannot_generate_qr(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.post(f"/students/{seeded_data['student_id']}/generate-qr", json={"reason": "x"}, headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 403

    def test_admin_can_generate_qr(self, client, seeded_data):
        token = login(client, "admin@testmail.example", "AdminPass123!")
        r = client.post(f"/students/{seeded_data['student_id']}/generate-qr", json={"reason": "test"}, headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        assert "qr_payload" in r.json()

    def test_student_cannot_view_another_students_record(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.get("/students/some-other-student-id", headers={"Authorization": f"Bearer {token}"})
        assert r.status_code in (403, 404)

    def test_student_cannot_list_all_students(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.get("/students", headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 403


class TestScanFlow:
    def test_first_scan_marks_in(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.post(
            "/scan/verify",
            json={"qr_payload": seeded_data["qr_payload"], "device_id": "d1", "location": "gate", "face_image_base64": seeded_data["face_b64"]},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "IN"

    def test_second_scan_within_cooldown_is_blocked(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        headers = {"Authorization": f"Bearer {token}"}
        body = {"qr_payload": seeded_data["qr_payload"], "device_id": "d1", "location": "gate", "face_image_base64": seeded_data["face_b64"]}
        r1 = client.post("/scan/verify", json=body, headers=headers)
        assert r1.status_code == 200
        r2 = client.post("/scan/verify", json=body, headers=headers)
        assert r2.status_code == 429

    def test_wrong_face_is_rejected(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        wrong_face = make_face_b64(seed=777)
        r = client.post(
            "/scan/verify",
            json={"qr_payload": seeded_data["qr_payload"], "device_id": "d1", "location": "gate", "face_image_base64": wrong_face},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 401
        assert r.json()["error_code"] == "FACE_MISMATCH"

    def test_tampered_qr_payload_rejected(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        tampered = seeded_data["qr_payload"][:-4] + "abcd"
        r = client.post(
            "/scan/verify",
            json={"qr_payload": tampered, "device_id": "d1", "location": "gate", "face_image_base64": seeded_data["face_b64"]},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 400
        assert r.json()["error_code"] == "QR_INVALID"

    def test_revoked_qr_rejected(self, client, seeded_data):
        admin_token = login(client, "admin@testmail.example", "AdminPass123!")
        client.post(f"/students/{seeded_data['student_id']}/revoke-qr", json={"reason": "left school"}, headers={"Authorization": f"Bearer {admin_token}"})

        student_token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.post(
            "/scan/verify",
            json={"qr_payload": seeded_data["qr_payload"], "device_id": "d1", "location": "gate", "face_image_base64": seeded_data["face_b64"]},
            headers={"Authorization": f"Bearer {student_token}"},
        )
        assert r.status_code == 400
        assert r.json()["error_code"] == "QR_REVOKED"

    def test_malformed_base64_image_rejected_gracefully(self, client, seeded_data):
        token = login(client, "student@testmail.example", "StudentPass123!")
        r = client.post(
            "/scan/verify",
            json={"qr_payload": seeded_data["qr_payload"], "device_id": "d1", "location": "gate", "face_image_base64": "not-valid-base64!!"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code in (400, 401, 422)


class TestValidation:
    def test_invalid_phone_number_rejected(self, client, seeded_data):
        admin_token = login(client, "admin@testmail.example", "AdminPass123!")
        r = client.post(
            "/students",
            json={"class": "10", "section": "A", "roll_number": "5", "name": "New Kid", "parent_name": "P", "parent_phone": "notaphone"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert r.status_code == 422

    def test_edit_requires_reason(self, client, seeded_data):
        admin_token = login(client, "admin@testmail.example", "AdminPass123!")
        r = client.patch(
            f"/students/{seeded_data['student_id']}",
            json={"name": "Renamed"},  # missing required `reason`
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert r.status_code == 422
